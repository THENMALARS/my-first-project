// Job API Configuration
const JOB_API_CONFIG = {
    // Using JSearch API via RapidAPI (Free tier: 100 requests/month)
    rapidApiKey: 'YOUR_RAPIDAPI_KEY_HERE', // Get from https://rapidapi.com/letscrape-6bRBa3QguO5/api/jsearch
    baseUrl: 'https://jsearch.p.rapidapi.com/search'
};
let jobListings = [];
let currentJob = null;
let isLoading = false;

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// ✅ NEW FUNCTION - Load employer-posted internships from localStorage
function loadEmployerPostedInternships() {
    const allInternships = [];
    
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        
        if (key.startsWith('employerInternships_')) {
            try {
                const internships = JSON.parse(localStorage.getItem(key));
                if (Array.isArray(internships)) {
                    internships.forEach(internship => {
                        allInternships.push({
                            id: 'emp_' + internship.id,
                            title: internship.title,
                            company: internship.companyName || 'Company',
                            location: internship.location,
                            description: internship.description.substring(0, 150) + '...',
                            salary: internship.isPaid ? `$${internship.stipendAmount} ${internship.stipendPeriod}` : 'Unpaid',
                            requirements: internship.requirements || [],
                            fullDescription: internship.description
                        });
                    });
                }
            } catch (e) {
                console.error('Error loading employer internships:', e);
            }
        }
    }
    
    return allInternships;
}

// Fetch Real-Time Internships from API
async function fetchRealTimeJobs() {
    isLoading = true;
    showLoadingState();
    
    // ✅ MODIFICATION - Load employer internships first
    const employerInternships = loadEmployerPostedInternships();
    
    try {
        // Method 1: Using JSearch API (Recommended - Real internships from Google/LinkedIn/Indeed)
        const response = await fetch(`${JOB_API_CONFIG.baseUrl}?query=internship&page=1&num_pages=1`, {
            method: 'GET',
            headers: {
                'X-RapidAPI-Key': JOB_API_CONFIG.rapidApiKey,
                'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
            }
        });
        if (!response.ok) {
            throw new Error('API request failed');
        }
        const data = await response.json();
        if (data.data && data.data.length > 0) {
            // Transform API data to our format
            const apiInternships = data.data.slice(0, 12).map((job, index) => ({
                id: index + 1,
                title: job.job_title || 'No Title',
                company: job.employer_name || 'Company',
                location: `${job.job_city || ''}, ${job.job_state || job.job_country || 'Remote'}`.trim(),
                description: job.job_description ? job.job_description.substring(0, 150) + '...' : 'No description available',
                salary: job.job_salary || job.job_min_salary ? `$${job.job_min_salary || '1,500'}/month - $${job.job_max_salary || '3,000'}/month` : 'Stipend provided',
                requirements: job.job_highlights?.Qualifications || [
                    'Currently pursuing degree',
                    'Strong communication skills',
                    'Eager to learn'
                ],
                fullDescription: job.job_description || 'Full internship description not available.',
                applyLink: job.job_apply_link || job.job_google_link || '#'
            }));
            
            // ✅ MODIFICATION - Combine employer + API internships
            jobListings = [...employerInternships, ...apiInternships];
        } else {
            // ✅ MODIFICATION - Use employer internships even if API fails
            jobListings = employerInternships;
            throw new Error('No internships found');
        }
    } catch (error) {
        console.error('Error fetching internships:', error);
        // ✅ MODIFICATION - Keep employer internships, add sample data if needed
        if (employerInternships.length === 0) {
            loadJobs();
        } else {
            jobListings = employerInternships;
        }
    } finally {
        isLoading = false;
        loadJobs();
    }
}

// Fallback Sample Internships (if API fails or no key provided)
function loadJobs() {
    // ✅ MODIFICATION - Load employer internships here too
    const employerInternships = loadEmployerPostedInternships();
    
    // Only load sample data if jobListings is empty
    if (jobListings.length === 0) {
        jobListings = [
            {
                id: 1,
                title: "Software Development Intern",
                company: "Tech Innovators Inc.",
                location: "Remote",
                description: "Join our team to work on real-world projects and learn modern software development practices.",
                salary: "$2,000/month stipend",
                requirements: [
                    "Currently pursuing Computer Science degree",
                    "Basic knowledge of programming (Python, Java, or JavaScript)",
                    "Strong problem-solving skills",
                    "Good communication skills"
                ],
                fullDescription: "This internship offers hands-on experience in software development. You'll work alongside experienced engineers on actual product features, participate in code reviews, and learn industry best practices. Perfect for students looking to gain practical experience."
            },
            {
                id: 2,
                title: "UX Design Intern",
                company: "Creative Digital",
                location: "Los Angeles, CA",
                description: "Learn user experience design while working on exciting projects for real clients.",
                salary: "$1,800/month stipend",
                requirements: [
                    "Pursuing degree in Design, HCI, or related field",
                    "Familiarity with design tools (Figma, Sketch)",
                    "Portfolio of design work",
                    "Passion for user-centered design"
                ],
                fullDescription: "As a UX Design Intern, you'll support our design team in creating user interfaces and experiences. You'll participate in user research, create wireframes and prototypes, and collaborate with developers to bring designs to life."
            },
            {
                id: 3,
                title: "Data Analytics Intern",
                company: "Data Insights Corp",
                location: "New York, NY",
                description: "Dive into data analysis and learn to extract meaningful insights from complex datasets.",
                salary: "$2,200/month stipend",
                requirements: [
                    "Pursuing degree in Statistics, Math, or Data Science",
                    "Basic Python or R programming skills",
                    "Understanding of statistical concepts",
                    "Excel proficiency"
                ],
                fullDescription: "Work with our analytics team to analyze data, create reports, and build dashboards. You'll gain experience with data visualization tools, statistical analysis, and business intelligence platforms."
            },
            {
                id: 4,
                title: "Marketing Intern",
                company: "Brand Builders",
                location: "Miami, FL",
                description: "Learn digital marketing strategies and help execute campaigns for various brands.",
                salary: "$1,500/month stipend",
                requirements: [
                    "Pursuing degree in Marketing, Communications, or Business",
                    "Social media savvy",
                    "Creative thinking",
                    "Strong writing skills"
                ],
                fullDescription: "Support our marketing team in planning and executing digital campaigns. You'll work on social media management, content creation, email marketing, and campaign analytics while learning from experienced marketers."
            },
            {
                id: 5,
                title: "Mobile App Development Intern",
                company: "App Studio",
                location: "San Jose, CA",
                description: "Build mobile applications and learn iOS or Android development from industry experts.",
                salary: "$2,500/month stipend",
                requirements: [
                    "Pursuing CS or related degree",
                    "Basic knowledge of Swift or Kotlin",
                    "Understanding of mobile UI/UX principles",
                    "Published app or personal project is a plus"
                ],
                fullDescription: "Join our mobile development team to create innovative apps for iOS and Android. You'll work on feature development, bug fixes, and learn best practices in mobile app architecture and deployment."
            },
            {
                id: 6,
                title: "Content Writing Intern",
                company: "MediaWorks",
                location: "Remote",
                description: "Create engaging content for blogs, social media, and marketing materials.",
                salary: "$1,200/month stipend",
                requirements: [
                    "Pursuing degree in English, Journalism, or Communications",
                    "Excellent writing and editing skills",
                    "Understanding of SEO basics",
                    "Ability to meet deadlines"
                ],
                fullDescription: "Work with our content team to create compelling articles, blog posts, and social media content. You'll learn content strategy, SEO optimization, and how to write for different platforms and audiences."
            }
        ];
        
        // ✅ MODIFICATION - Prepend employer internships
        jobListings = [...employerInternships, ...jobListings];
    }
    displayJobs();
}

// Show Loading State
function showLoadingState() {
    const jobsGrid = document.getElementById('jobsGrid');
    if (jobsGrid) {
        jobsGrid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px;">
                <div style="font-size: 48px; margin-bottom: 20px;">⏳</div>
                <p style="font-size: 18px; color: #666; font-weight: 600;">Loading latest internship opportunities...</p>
            </div>
        `;
    }
}

// Display Jobs
function displayJobs() {
    const jobsGrid = document.getElementById('jobsGrid');
    if (!jobsGrid) {
        console.error('jobsGrid element not found');
        return;
    }
    if (jobListings.length === 0) {
        jobsGrid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px;">
                <p style="font-size: 18px; color: #666;">No internships available at the moment. Please try again later.</p>
            </div>
        `;
        return;
    }
    jobsGrid.innerHTML = jobListings.map(job => `
        <div class="job-card" onclick="openJobModal(${typeof job.id === 'string' ? "'" + job.id + "'" : job.id})">
            <h3>${job.title}</h3>
            <p class="company">🏢 ${job.company}</p>
            <p class="location">📍 ${job.location}</p>
            <p class="description">${job.description}</p>
            <div class="card-footer">
                <span class="salary">💰 ${job.salary}</span>
                <button class="view-details" onclick="event.stopPropagation(); openJobModal(${typeof job.id === 'string' ? "'" + job.id + "'" : job.id})">View Details</button>
            </div>
        </div>
    `).join('');
}

// Open Job Modal
function openJobModal(jobId) {
    currentJob = jobListings.find(job => job.id === jobId || job.id == jobId);
    if (currentJob) {
        document.getElementById('modalJobTitle').textContent = currentJob.title;
        document.getElementById('modalCompany').textContent = currentJob.company;
        document.getElementById('modalLocation').textContent = `📍 ${currentJob.location}`;
        document.getElementById('modalDescription').textContent = currentJob.fullDescription;
        document.getElementById('modalSalary').textContent = currentJob.salary;
        const requirementsList = document.getElementById('modalRequirements');
        requirementsList.innerHTML = currentJob.requirements.map(req => 
            `<li>${req}</li>`
        ).join('');
        document.getElementById('jobModal').classList.add('active');
    }
}

// Close Job Modal
function closeJobModal() {
    document.getElementById('jobModal').classList.remove('active');
    currentJob = null;
}

// Apply for Job
function applyForJob() {
    if (currentJob) {
        // Get dashboard data
        let dashboardData = JSON.parse(localStorage.getItem('dashboardData')) || {
            appliedJobs: 0,
            appliedInternships: 0
        };
        // Increment applied internships count
        dashboardData.appliedInternships++;
        // Save to localStorage
        localStorage.setItem('dashboardData', JSON.stringify(dashboardData));
        // Record application with date for timeline graph
        recordApplicationWithDate('internship');
        // If external apply link exists, open it
        if (currentJob.applyLink && currentJob.applyLink !== '#') {
            window.open(currentJob.applyLink, '_blank');
        }
        // Show success notification
        showNotification(`Successfully applied to ${currentJob.title} at ${currentJob.company}!`);
        // Close modal
        closeJobModal();
    }
}

// Record Application with Date (for timeline tracking)
function recordApplicationWithDate(type) {
    const today = new Date().toISOString().split('T')[0];
    let applicationHistory = JSON.parse(localStorage.getItem('applicationHistory')) || [];
    let todayEntry = applicationHistory.find(entry => entry.date === today);
    if (!todayEntry) {
        todayEntry = {
            date: today,
            jobs: 0,
            internships: 0,
            posts: 0
        };
        applicationHistory.push(todayEntry);
    }
    if (type === 'job') {
        todayEntry.jobs++;
    } else if (type === 'internship') {
        todayEntry.internships++;
    }
    applicationHistory.sort((a, b) => new Date(a.date) - new Date(b.date));
    if (applicationHistory.length > 30) {
        applicationHistory = applicationHistory.slice(-30);
    }
    localStorage.setItem('applicationHistory', JSON.stringify(applicationHistory));
}

// Show Notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 30px;
        background: #4CAF50;
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        z-index: 3000;
        animation: slideIn 0.3s ease;
        font-weight: 600;
        max-width: 350px;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Refresh Jobs Button
function refreshJobs() {
    fetchRealTimeJobs();
    showNotification('Refreshing internship listings...');
}

// Logout User
function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    }
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    const modal = document.getElementById('jobModal');
    if (e.target === modal) {
        closeJobModal();
    }
});

// Close modal and sidebar with Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeJobModal();
        const sidebar = document.getElementById('sidebar');
        if (sidebar.classList.contains('active')) {
            toggleSidebar();
        }
    }
});

// Close sidebar when clicking on a link
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.sidebar-link').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                toggleSidebar();
            }
        });
    });
});

// Check if user is logged in and load jobs
window.addEventListener('load', function() {
    const token = localStorage.getItem('token');
    if (!token) {
        alert('Please login to apply for internships');
        window.location.href = 'index.html';
    } else {
        // Try to fetch real-time jobs first
        if (JOB_API_CONFIG.rapidApiKey && JOB_API_CONFIG.rapidApiKey !== 'YOUR_RAPIDAPI_KEY_HERE') {
            fetchRealTimeJobs();
        } else {
            // Use sample data if no API key
            loadJobs();
            console.warn('No API key provided. Using sample data. Get your free API key from https://rapidapi.com/');
        }
    }
});

// Auto-refresh jobs every 24 hours
setInterval(() => {
    if (JOB_API_CONFIG.rapidApiKey && JOB_API_CONFIG.rapidApiKey !== 'YOUR_RAPIDAPI_KEY_HERE') {
        console.log('Auto-refreshing internship listings...');
        fetchRealTimeJobs();
    }
}, 24 * 60 * 60 * 1000); // 24 hours

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100px);
        }
    }
`;
document.head.appendChild(style);