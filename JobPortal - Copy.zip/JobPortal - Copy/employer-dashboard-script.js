// Employer Dashboard Data
let employerDashboardData = {
    postedJobs: 0,
    postedInternships: 0,
    totalApplications: 0,
    applicationHistory: [] // Track history with dates
};
let statsChart = null;

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// Close sidebar when clicking on a link
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.sidebar-link').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                toggleSidebar();
            }
        });
    });
});

// Initialize Application History
function initializeApplicationHistory() {
    const storedHistory = localStorage.getItem('employerApplicationHistory');
    if (storedHistory) {
        employerDashboardData.applicationHistory = JSON.parse(storedHistory);
    } else {
        employerDashboardData.applicationHistory = [];
    }
}

// Get Historical Data for Chart
function getChartData() {
    if (employerDashboardData.applicationHistory.length === 0) {
        // Generate last 7 days of data
        const dates = [];
        const jobsData = [];
        const internshipsData = [];
        const applicationsData = [];
        
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            dates.push(dateStr);
            jobsData.push(0);
            internshipsData.push(0);
            applicationsData.push(0);
        }
        
        return { dates, jobsData, internshipsData, applicationsData };
    }
    
    const recentHistory = employerDashboardData.applicationHistory.slice(-7);
    
    const dates = recentHistory.map(entry => {
        const date = new Date(entry.date);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    });
    
    const jobsData = recentHistory.map(entry => entry.jobs);
    const internshipsData = recentHistory.map(entry => entry.internships);
    const applicationsData = recentHistory.map(entry => entry.applications);
    
    return { dates, jobsData, internshipsData, applicationsData };
}

// Load Dashboard Data
function loadDashboard() {
    // Get user data
    const user = localStorage.getItem('user');
    const companyProfileData = localStorage.getItem('companyProfileData');
    const storedDashboardData = localStorage.getItem('employerDashboardData');
    const employerJobs = localStorage.getItem('employerJobs');
    const employerInternships = localStorage.getItem('employerInternships');

    if (user) {
        const userData = JSON.parse(user);
        document.getElementById('companyName').textContent = userData.fullName || 'Company Name';
        document.getElementById('companyDisplayName').textContent = userData.fullName || 'Your Company';
    }

    if (companyProfileData) {
        const profile = JSON.parse(companyProfileData);
        document.getElementById('companyIndustry').textContent =
            profile.industry || 'Add your company industry in Company Profile';
        if (profile.logo) {
            document.getElementById('companyLogo').src = profile.logo;
        }
    }

    if (storedDashboardData) {
        employerDashboardData = JSON.parse(storedDashboardData);
    }

    // Get job posts count
    let jobsCount = 0;
    if (employerJobs) {
        const jobs = JSON.parse(employerJobs);
        jobsCount = jobs.length;
        employerDashboardData.postedJobs = jobsCount;
    }

    // Get internship posts count
    let internshipsCount = 0;
    if (employerInternships) {
        const internships = JSON.parse(employerInternships);
        internshipsCount = internships.length;
        employerDashboardData.postedInternships = internshipsCount;
    }

    initializeApplicationHistory();
    updateDashboardCounts();
    createChart();
}

// Update Dashboard Counts
function updateDashboardCounts() {
    document.getElementById('postedJobsCount').textContent = employerDashboardData.postedJobs;
    document.getElementById('postedInternshipsCount').textContent = employerDashboardData.postedInternships;
    document.getElementById('totalApplicationsCount').textContent = employerDashboardData.totalApplications;

    // Update stats summary
    document.getElementById('statJobsCount').textContent = employerDashboardData.postedJobs;
    document.getElementById('statInternshipsCount').textContent = employerDashboardData.postedInternships;
    document.getElementById('statApplicationsCount').textContent = employerDashboardData.totalApplications;
}

// Create Statistics Chart (Line Chart)
function createChart() {
    const ctx = document.getElementById('statsChart');

    if (statsChart) {
        statsChart.destroy();
    }

    const chartData = getChartData();

    statsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: chartData.dates,
            datasets: [
                {
                    label: 'Jobs Posted',
                    data: chartData.jobsData,
                    borderColor: 'rgba(102, 126, 234, 1)',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderWidth: 3,
                    pointRadius: 5,
                    pointBackgroundColor: 'rgba(102, 126, 234, 1)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointHoverRadius: 7,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Internships Posted',
                    data: chartData.internshipsData,
                    borderColor: 'rgba(240, 147, 251, 1)',
                    backgroundColor: 'rgba(240, 147, 251, 0.1)',
                    borderWidth: 3,
                    pointRadius: 5,
                    pointBackgroundColor: 'rgba(240, 147, 251, 1)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointHoverRadius: 7,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Applications Received',
                    data: chartData.applicationsData,
                    borderColor: 'rgba(79, 172, 254, 1)',
                    backgroundColor: 'rgba(79, 172, 254, 0.1)',
                    borderWidth: 3,
                    pointRadius: 5,
                    pointBackgroundColor: 'rgba(79, 172, 254, 1)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointHoverRadius: 7,
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        font: {
                            size: 12,
                            weight: 'bold'
                        },
                        color: '#1a3a52',
                        padding: 15,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                title: {
                    display: true,
                    text: 'Activity Timeline (Last 7 Days)',
                    font: {
                        size: 16,
                        weight: 'bold'
                    },
                    color: '#1a3a52',
                    padding: {
                        bottom: 20
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    padding: 12,
                    displayColors: true,
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            label += context.parsed.y;
                            return label;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        font: {
                            size: 12
                        },
                        color: '#5a6a7a'
                    },
                    grid: {
                        color: 'rgba(26, 58, 82, 0.1)',
                        drawBorder: false
                    },
                    title: {
                        display: true,
                        text: 'Count',
                        color: '#1a3a52',
                        font: {
                            size: 13,
                            weight: 'bold'
                        }
                    }
                },
                x: {
                    ticks: {
                        font: {
                            size: 11,
                            weight: '600'
                        },
                        color: '#1a3a52'
                    },
                    grid: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'Date',
                        color: '#1a3a52',
                        font: {
                            size: 13,
                            weight: 'bold'
                        }
                    }
                }
            }
        }
    });
}

// Logout User
function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    }
}

// Sidebar Navigation
document.querySelectorAll('.sidebar-link').forEach(link => {
    link.addEventListener('click', function(e) {
        document.querySelectorAll('.sidebar-link').forEach(l => {
            l.classList.remove('active');
        });
        this.classList.add('active');
    });
});

// Check if user is logged in and is an employer
window.addEventListener('load', function() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (!token) {
        alert('Please login to view your dashboard');
        window.location.href = 'index.html';
    } else {
        const userData = JSON.parse(user);
        
        // Check if user is employer
        if (userData.role !== 'employee') {
            alert('This page is only for employers. Redirecting to job seeker dashboard...');
            window.location.href = 'dashboard.html';
        } else {
            loadDashboard();
        }
    }
});