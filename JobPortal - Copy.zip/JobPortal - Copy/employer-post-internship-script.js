// Helper function to get user-specific key
function getUserKey(baseKey) {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const userId = user.id || user.email || 'default';
    return `${baseKey}_${userId}`;
}

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// Format requirements/responsibilities from textarea to array
function formatListItems(text) {
    if (!text) return [];
    return text.split('\n')
        .map(line => line.trim())
        .filter(line => line.length > 0)
        .map(line => line.replace(/^[•\-]\s*/, ''));
}

// Preview Internship
function previewInternship() {
    const internshipData = collectFormData();
    
    if (!validateRequiredFields()) {
        showNotification('Please fill in all required fields!', 'error');
        return;
    }

    const preview = document.getElementById('internshipPreview');
    preview.innerHTML = generateInternshipPreview(internshipData);
    document.getElementById('previewModal').classList.add('active');
}

// Close Preview
function closePreview() {
    document.getElementById('previewModal').classList.remove('active');
}

// Validate Required Fields
function validateRequiredFields() {
    const required = [
        'internshipTitle', 'internshipCategory', 'internshipDuration', 'internshipLocation',
        'workMode', 'internshipType', 'internshipDescription', 'internshipRequirements',
        'positions', 'applicationEmail'
    ];

    for (const field of required) {
        const element = document.getElementById(field);
        if (!element.value || element.value.toString().trim() === '') {
            element.focus();
            return false;
        }
    }

    return true;
}

// Collect Form Data
function collectFormData() {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const stipend = document.getElementById('stipendAmount').value;
    
    return {
        id: Date.now(),
        type: 'internship',
        title: document.getElementById('internshipTitle').value.trim(),
        category: document.getElementById('internshipCategory').value,
        duration: document.getElementById('internshipDuration').value,
        location: document.getElementById('internshipLocation').value.trim(),
        workMode: document.getElementById('workMode').value,
        startDate: document.getElementById('startDate').value,
        internshipType: document.getElementById('internshipType').value,
        description: document.getElementById('internshipDescription').value.trim(),
        requirements: formatListItems(document.getElementById('internshipRequirements').value),
        responsibilities: formatListItems(document.getElementById('responsibilities').value),
        learningOutcomes: formatListItems(document.getElementById('learningOutcomes').value),
        stipend: stipend ? parseFloat(stipend) : null,
        stipendPeriod: document.getElementById('stipendPeriod').value,
        benefits: formatListItems(document.getElementById('benefits').value),
        eligibility: document.getElementById('eligibility').value.trim(),
        positions: parseInt(document.getElementById('positions').value),
        applicationDeadline: document.getElementById('applicationDeadline').value,
        applicationEmail: document.getElementById('applicationEmail').value.trim(),
        applicationUrl: document.getElementById('applicationUrl').value.trim(),
        company: user.fullName || 'Company Name',
        postedBy: user.id || user.email,
        postedDate: new Date().toISOString(),
        status: 'active'
    };
}

// Generate Internship Preview HTML
function generateInternshipPreview(data) {
    let stipendText = data.internshipType;
    if (data.stipend && data.internshipType === 'Paid') {
        stipendText = `$${data.stipend.toLocaleString()} ${data.stipendPeriod}`;
    }
    
    let html = `
        <h3>${data.title}</h3>
        <div class="meta-info">
            <span class="meta-tag">${data.company}</span>
            <span class="meta-tag">📍 ${data.location}</span>
            <span class="meta-tag">⏱️ ${data.duration}</span>
            <span class="meta-tag">🏢 ${data.workMode}</span>
            <span class="meta-tag">💰 ${stipendText}</span>
            <span class="meta-tag">👥 ${data.positions} position(s)</span>
        </div>
    `;

    html += `
        <div class="preview-section">
            <h4>About This Internship</h4>
            <p>${data.description}</p>
        </div>
    `;

    if (data.requirements.length > 0) {
        html += `
            <div class="preview-section">
                <h4>Requirements</h4>
                <ul>
                    ${data.requirements.map(req => `<li>${req}</li>`).join('')}
                </ul>
            </div>
        `;
    }

    if (data.responsibilities.length > 0) {
        html += `
            <div class="preview-section">
                <h4>What You'll Do</h4>
                <ul>
                    ${data.responsibilities.map(resp => `<li>${resp}</li>`).join('')}
                </ul>
            </div>
        `;
    }

    if (data.learningOutcomes.length > 0) {
        html += `
            <div class="preview-section">
                <h4>Learning Outcomes</h4>
                <ul>
                    ${data.learningOutcomes.map(outcome => `<li>${outcome}</li>`).join('')}
                </ul>
            </div>
        `;
    }

    if (data.benefits.length > 0) {
        html += `
            <div class="preview-section">
                <h4>Benefits & Perks</h4>
                <ul>
                    ${data.benefits.map(benefit => `<li>${benefit}</li>`).join('')}
                </ul>
            </div>
        `;
    }

    if (data.eligibility) {
        html += `
            <div class="preview-section">
                <h4>Eligibility</h4>
                <p>${data.eligibility}</p>
            </div>
        `;
    }

    html += `
        <div class="preview-section">
            <h4>How to Apply</h4>
            <p>Email: <strong>${data.applicationEmail}</strong></p>
            ${data.applicationUrl ? `<p>Application Link: <a href="${data.applicationUrl}" target="_blank">${data.applicationUrl}</a></p>` : ''}
            ${data.startDate ? `<p>Start Date: <strong>${new Date(data.startDate).toLocaleDateString()}</strong></p>` : ''}
            ${data.applicationDeadline ? `<p>Application Deadline: <strong>${new Date(data.applicationDeadline).toLocaleDateString()}</strong></p>` : ''}
        </div>
    `;

    return html;
}

// Submit Internship
function submitInternship(event) {
    event.preventDefault();

    if (!validateRequiredFields()) {
        showNotification('Please fill in all required fields!', 'error');
        return;
    }

    const internshipData = collectFormData();

    let employerInternships = JSON.parse(localStorage.getItem(getUserKey('employerInternships')) || '[]');
    employerInternships.unshift(internshipData);
    localStorage.setItem(getUserKey('employerInternships'), JSON.stringify(employerInternships));

    let employerDashboardData = JSON.parse(localStorage.getItem(getUserKey('employerDashboardData')) || '{}');
    employerDashboardData.postedInternships = employerInternships.length;
    localStorage.setItem(getUserKey('employerDashboardData'), JSON.stringify(employerDashboardData));

    recordActivity('internship');

    showNotification('Internship posted successfully! 🎉');

    setTimeout(() => {
        window.location.href = 'employer-my-posts.html';
    }, 2000);
}

// Record Activity for Timeline
function recordActivity(type) {
    const today = new Date().toISOString().split('T')[0];
    let applicationHistory = JSON.parse(localStorage.getItem(getUserKey('employerApplicationHistory')) || '[]');
    let todayEntry = applicationHistory.find(entry => entry.date === today);
    
    if (!todayEntry) {
        todayEntry = { date: today, jobs: 0, internships: 0, applications: 0 };
        applicationHistory.push(todayEntry);
    }
    
    if (type === 'internship') todayEntry.internships++;
    
    applicationHistory.sort((a, b) => new Date(a.date) - new Date(b.date));
    if (applicationHistory.length > 30) {
        applicationHistory = applicationHistory.slice(-30);
    }
    
    localStorage.setItem(getUserKey('employerApplicationHistory'), JSON.stringify(applicationHistory));
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    const bgColor = type === 'error' ? '#f44336' : '#4CAF50';
    notification.style.cssText = `position: fixed; top: 80px; right: 30px; background: ${bgColor}; color: white; padding: 15px 25px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2); z-index: 3000; animation: slideIn 0.3s ease; font-weight: 600; max-width: 350px;`;
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => document.body.removeChild(notification), 300);
    }, 3000);
}

function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    }
}

document.addEventListener('click', function(e) {
    const modal = document.getElementById('previewModal');
    if (e.target === modal) closePreview();
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePreview();
        const sidebar = document.getElementById('sidebar');
        if (sidebar.classList.contains('active')) toggleSidebar();
    }
});

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.sidebar-link').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                toggleSidebar();
            }
        });
    });
});

window.addEventListener('load', function() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    if (!token) {
        alert('Please login to post an internship');
        window.location.href = 'index.html';
    } else {
        const userData = JSON.parse(user);
        if (userData.role !== 'employee') {
            alert('Only employers can post internships. Redirecting...');
            window.location.href = 'dashboard.html';
        }
    }
});

const style = document.createElement('style');
style.textContent = `@keyframes slideIn { from { opacity: 0; transform: translateX(100px); } to { opacity: 1; transform: translateX(0); } } @keyframes slideOut { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(100px); } }`;
document.head.appendChild(style);