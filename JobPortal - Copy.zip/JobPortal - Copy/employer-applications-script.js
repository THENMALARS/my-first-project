// =============================================
// EMPLOYER APPLICATIONS MANAGEMENT
// =============================================

// Sample data (replace with actual API calls)
let applications = [
    {
        id: 1,
        applicantName: "Sarah Johnson",
        email: "sarah.johnson@email.com",
        phone: "+1 (555) 123-4567",
        avatar: "https://i.pravatar.cc/150?img=1",
        position: "Senior Frontend Developer",
        jobId: "job_001",
        appliedDate: "2025-02-05",
        status: "new",
        location: "San Francisco, CA",
        experience: "5 years",
        skills: ["React", "TypeScript", "Node.js", "GraphQL"],
        coverLetter: "I am excited to apply for the Senior Frontend Developer position. With 5 years of experience building scalable web applications, I believe I would be a great fit for your team...",
        resumeUrl: "resumes/sarah_johnson_resume.pdf"
    },
    {
        id: 2,
        applicantName: "Michael Chen",
        email: "michael.chen@email.com",
        phone: "+1 (555) 234-5678",
        avatar: "https://i.pravatar.cc/150?img=12",
        position: "Backend Developer Internship",
        jobId: "internship_001",
        appliedDate: "2025-02-06",
        status: "reviewed",
        location: "New York, NY",
        experience: "2 years",
        skills: ["Python", "Django", "PostgreSQL", "Docker"],
        coverLetter: "As a recent graduate with hands-on experience in backend development...",
        resumeUrl: "resumes/michael_chen_resume.pdf"
    },
    {
        id: 3,
        applicantName: "Emily Davis",
        email: "emily.davis@email.com",
        phone: "+1 (555) 345-6789",
        avatar: "https://i.pravatar.cc/150?img=5",
        position: "Senior Frontend Developer",
        jobId: "job_001",
        appliedDate: "2025-02-07",
        status: "shortlisted",
        location: "Austin, TX",
        experience: "4 years",
        skills: ["Vue.js", "JavaScript", "CSS", "REST APIs"],
        coverLetter: "I am writing to express my strong interest in the Frontend Developer role...",
        resumeUrl: "resumes/emily_davis_resume.pdf"
    },
    {
        id: 4,
        applicantName: "David Martinez",
        email: "david.martinez@email.com",
        phone: "+1 (555) 456-7890",
        avatar: "https://i.pravatar.cc/150?img=13",
        position: "Backend Developer Internship",
        jobId: "internship_001",
        appliedDate: "2025-02-08",
        status: "interview",
        location: "Seattle, WA",
        experience: "1 year",
        skills: ["Java", "Spring Boot", "MySQL", "AWS"],
        coverLetter: "I am thrilled to apply for the Backend Developer Internship position...",
        resumeUrl: "resumes/david_martinez_resume.pdf"
    }
];

let currentFilter = 'all';
let currentJobFilter = 'all';
let currentApplicant = null;

// =============================================
// INITIALIZATION
// =============================================

document.addEventListener('DOMContentLoaded', function() {
    loadApplications();
    loadJobFilters();
    updateCounts();
});

// =============================================
// SIDEBAR FUNCTIONS
// =============================================

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// =============================================
// LOAD APPLICATIONS
// =============================================

function loadApplications() {
    const container = document.getElementById('applicantsContainer');
    const emptyState = document.getElementById('emptyState');
    
    // Filter applications
    let filteredApps = applications;
    
    // Filter by status
    if (currentFilter !== 'all') {
        filteredApps = filteredApps.filter(app => app.status === currentFilter);
    }
    
    // Filter by job
    if (currentJobFilter !== 'all') {
        filteredApps = filteredApps.filter(app => app.jobId === currentJobFilter);
    }
    
    // Check if empty
    if (filteredApps.length === 0) {
        container.style.display = 'none';
        emptyState.style.display = 'block';
        return;
    }
    
    container.style.display = 'grid';
    emptyState.style.display = 'none';
    
    // Render applications
    container.innerHTML = filteredApps.map(app => `
        <div class="applicant-card" onclick="viewApplicant(${app.id})">
            <img src="${app.avatar}" alt="${app.applicantName}" class="applicant-avatar">
            
            <div class="applicant-details">
                <div class="applicant-name">${app.applicantName}</div>
                <div class="applicant-position">${app.position}</div>
                <div class="applicant-meta">
                    <span>📧 ${app.email}</span>
                    <span>📍 ${app.location}</span>
                </div>
            </div>
            
            <div class="applicant-info">
                <div class="status-badge ${app.status}">${formatStatus(app.status)}</div>
                <div class="applicant-date">Applied: ${formatDate(app.appliedDate)}</div>
            </div>
            
            <div class="applicant-actions">
                <button class="btn-view" onclick="event.stopPropagation(); viewApplicant(${app.id})">
                    View Details
                </button>
            </div>
        </div>
    `).join('');
}

// =============================================
// FILTER FUNCTIONS
// =============================================

function filterByStatus(status) {
    currentFilter = status;
    
    // Update active tab
    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    event.target.classList.add('active');
    
    loadApplications();
}

function filterByJob() {
    const select = document.getElementById('jobFilter');
    currentJobFilter = select.value;
    loadApplications();
}

function searchApplicants() {
    const searchTerm = document.getElementById('searchApplicant').value.toLowerCase();
    const cards = document.querySelectorAll('.applicant-card');
    
    cards.forEach(card => {
        const name = card.querySelector('.applicant-name').textContent.toLowerCase();
        const email = card.querySelector('.applicant-meta span').textContent.toLowerCase();
        
        if (name.includes(searchTerm) || email.includes(searchTerm)) {
            card.style.display = 'grid';
        } else {
            card.style.display = 'none';
        }
    });
}

// =============================================
// LOAD JOB FILTERS
// =============================================

function loadJobFilters() {
    const select = document.getElementById('jobFilter');
    
    // Get unique jobs from applications
    const jobs = [...new Set(applications.map(app => ({
        id: app.jobId,
        title: app.position
    })))];
    
    // Remove duplicates by position
    const uniqueJobs = jobs.filter((job, index, self) =>
        index === self.findIndex((t) => t.title === job.title)
    );
    
    // Add options
    uniqueJobs.forEach(job => {
        const option = document.createElement('option');
        option.value = job.id;
        option.textContent = job.title;
        select.appendChild(option);
    });
}

// =============================================
// UPDATE COUNTS
// =============================================

function updateCounts() {
    const total = applications.length;
    const newCount = applications.filter(app => app.status === 'new').length;
    const reviewed = applications.filter(app => app.status === 'reviewed').length;
    const shortlisted = applications.filter(app => app.status === 'shortlisted').length;
    const rejected = applications.filter(app => app.status === 'rejected').length;
    
    document.getElementById('totalApplicants').textContent = total;
    document.getElementById('newApplicants').textContent = newCount;
    document.getElementById('countAll').textContent = total;
    document.getElementById('countNew').textContent = newCount;
    document.getElementById('countReviewed').textContent = reviewed;
    document.getElementById('countShortlisted').textContent = shortlisted;
    document.getElementById('countRejected').textContent = rejected;
}

// =============================================
// VIEW APPLICANT MODAL
// =============================================

function viewApplicant(applicantId) {
    const applicant = applications.find(app => app.id === applicantId);
    if (!applicant) return;
    
    currentApplicant = applicant;
    
    // Populate modal
    document.getElementById('modalName').textContent = applicant.applicantName;
    document.getElementById('modalEmail').textContent = applicant.email;
    document.getElementById('modalAvatar').src = applicant.avatar;
    document.getElementById('modalPosition').textContent = applicant.position;
    document.getElementById('modalDate').textContent = formatDate(applicant.appliedDate);
    document.getElementById('modalPhone').textContent = applicant.phone;
    document.getElementById('modalLocation').textContent = applicant.location;
    document.getElementById('modalExperience').textContent = applicant.experience;
    document.getElementById('modalCoverLetter').textContent = applicant.coverLetter;
    
    // Status badge
    const statusBadge = document.getElementById('modalStatusBadge');
    statusBadge.textContent = formatStatus(applicant.status);
    statusBadge.className = `status-badge ${applicant.status}`;
    
    // Skills
    const skillsContainer = document.getElementById('modalSkills');
    skillsContainer.innerHTML = applicant.skills.map(skill => 
        `<span class="skill-tag">${skill}</span>`
    ).join('');
    
    // Resume
    const resumeSection = document.getElementById('resumeSection');
    if (applicant.resumeUrl) {
        resumeSection.innerHTML = `
            <a href="${applicant.resumeUrl}" class="resume-link" target="_blank">
                <span>📄</span>
                <span>View Resume/CV</span>
            </a>
        `;
    }
    
    // Set current status in select
    document.getElementById('statusSelect').value = applicant.status;
    
    // Show modal
    document.getElementById('applicantModal').classList.add('active');
}

function closeApplicantModal() {
    document.getElementById('applicantModal').classList.remove('active');
    currentApplicant = null;
}

// =============================================
// UPDATE APPLICANT STATUS
// =============================================

function updateApplicantStatus() {
    if (!currentApplicant) return;
    
    const newStatus = document.getElementById('statusSelect').value;
    const sendEmail = document.getElementById('sendEmailNotification').checked;
    const customMessage = document.getElementById('emailMessage').value.trim();
    
    // Update status in data
    const appIndex = applications.findIndex(app => app.id === currentApplicant.id);
    if (appIndex !== -1) {
        applications[appIndex].status = newStatus;
    }
    
    // Send email if checkbox is checked
    if (sendEmail) {
        sendStatusEmail(currentApplicant, newStatus, customMessage);
    }
    
    // Update UI
    loadApplications();
    updateCounts();
    closeApplicantModal();
    
    // Show success toast
    showToast('Application status updated successfully!');
    
    // Clear email message
    document.getElementById('emailMessage').value = '';
}

// =============================================
// EMAIL NOTIFICATION SYSTEM
// =============================================

function sendStatusEmail(applicant, status, customMessage) {
    const emailTemplates = {
        new: {
            subject: `Application Received - ${applicant.position}`,
            body: `Dear ${applicant.applicantName},\n\nThank you for applying for the ${applicant.position} position. We have received your application and will review it shortly.\n\nBest regards,\nHiring Team`
        },
        reviewed: {
            subject: `Application Under Review - ${applicant.position}`,
            body: `Dear ${applicant.applicantName},\n\nYour application for the ${applicant.position} position is currently under review. We will get back to you soon.\n\nBest regards,\nHiring Team`
        },
        shortlisted: {
            subject: `Congratulations! You've Been Shortlisted - ${applicant.position}`,
            body: `Dear ${applicant.applicantName},\n\nCongratulations! We are pleased to inform you that you have been shortlisted for the ${applicant.position} position. We will contact you soon to schedule the next steps.\n\nBest regards,\nHiring Team`
        },
        interview: {
            subject: `Interview Scheduled - ${applicant.position}`,
            body: `Dear ${applicant.applicantName},\n\nWe would like to invite you for an interview for the ${applicant.position} position. We will send you the interview details shortly.\n\nBest regards,\nHiring Team`
        },
        rejected: {
            subject: `Application Status - ${applicant.position}`,
            body: `Dear ${applicant.applicantName},\n\nThank you for your interest in the ${applicant.position} position. After careful consideration, we have decided to move forward with other candidates. We appreciate your time and wish you the best in your job search.\n\nBest regards,\nHiring Team`
        },
        hired: {
            subject: `Congratulations! Job Offer - ${applicant.position}`,
            body: `Dear ${applicant.applicantName},\n\nCongratulations! We are thrilled to offer you the ${applicant.position} position. We will send you the offer letter and next steps shortly.\n\nBest regards,\nHiring Team`
        }
    };
    
    const template = emailTemplates[status] || emailTemplates.new;
    const finalMessage = customMessage || template.body;
    
    // Simulate sending email (replace with actual email API)
    console.log('Sending Email:');
    console.log('To:', applicant.email);
    console.log('Subject:', template.subject);
    console.log('Message:', finalMessage);
    
    // In production, integrate with email service like:
    // - SendGrid
    // - Mailgun
    // - AWS SES
    // - Your backend API endpoint
    
    /*
    // Example using fetch to backend API:
    fetch('/api/send-email', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            to: applicant.email,
            subject: template.subject,
            message: finalMessage,
            applicantName: applicant.applicantName,
            position: applicant.position
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Email sent successfully:', data);
    })
    .catch(error => {
        console.error('Error sending email:', error);
    });
    */
}

// =============================================
// DELETE APPLICATION
// =============================================

function deleteApplication() {
    if (!currentApplicant) return;
    
    if (confirm(`Are you sure you want to delete the application from ${currentApplicant.applicantName}?`)) {
        // Remove from array
        applications = applications.filter(app => app.id !== currentApplicant.id);
        
        // Update UI
        loadApplications();
        updateCounts();
        closeApplicantModal();
        
        showToast('Application deleted successfully!');
    }
}

// =============================================
// UTILITY FUNCTIONS
// =============================================

function formatStatus(status) {
    const statusMap = {
        'new': 'New',
        'reviewed': 'Reviewed',
        'shortlisted': 'Shortlisted',
        'interview': 'Interview',
        'rejected': 'Rejected',
        'hired': 'Hired'
    };
    return statusMap[status] || status;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const options = { month: 'short', day: 'numeric', year: 'numeric' };
    return date.toLocaleDateString('en-US', options);
}

function showToast(message) {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    toastMessage.textContent = message;
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// =============================================
// LOGOUT FUNCTION
// =============================================

function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('userToken');
        localStorage.removeItem('userData');
        window.location.href = 'index.html';
    }
}

// =============================================
// LOAD APPLICATIONS FROM BACKEND (EXAMPLE)
// =============================================

/*
// Example function to load applications from your backend API
async function loadApplicationsFromAPI() {
    try {
        const token = localStorage.getItem('userToken');
        const response = await fetch('/api/employer/applications', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            applications = data.applications;
            loadApplications();
            updateCounts();
        }
    } catch (error) {
        console.error('Error loading applications:', error);
    }
}
*/