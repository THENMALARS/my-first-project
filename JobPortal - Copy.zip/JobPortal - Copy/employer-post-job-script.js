// Helper function to get user-specific key
function getUserKey(baseKey) {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const userId = user.id || user.email || 'default';
    return `${baseKey}_${userId}`;
}

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// Format requirements/responsibilities from textarea to array
function formatListItems(text) {
    if (!text) return [];
    return text.split('\n')
        .map(line => line.trim())
        .filter(line => line.length > 0)
        .map(line => line.replace(/^[•\-]\s*/, '')); // Remove bullet points
}

// Preview Job
function previewJob() {
    const jobData = collectFormData();
    
    if (!validateRequiredFields()) {
        showNotification('Please fill in all required fields!', 'error');
        return;
    }

    const preview = document.getElementById('jobPreview');
    preview.innerHTML = generateJobPreview(jobData);
    document.getElementById('previewModal').classList.add('active');
}

// Close Preview
function closePreview() {
    document.getElementById('previewModal').classList.remove('active');
}

// Validate Required Fields
function validateRequiredFields() {
    const required = [
        'jobTitle', 'jobCategory', 'jobType', 'jobLocation', 'workMode',
        'jobDescription', 'jobRequirements', 'salaryMin', 'salaryMax',
        'salaryPeriod', 'experienceLevel', 'applicationEmail'
    ];

    for (const field of required) {
        const element = document.getElementById(field);
        if (!element.value.trim()) {
            element.focus();
            return false;
        }
    }

    // Validate salary range
    const salaryMin = parseFloat(document.getElementById('salaryMin').value);
    const salaryMax = parseFloat(document.getElementById('salaryMax').value);
    
    if (salaryMax < salaryMin) {
        showNotification('Maximum salary must be greater than minimum salary!', 'error');
        document.getElementById('salaryMax').focus();
        return false;
    }

    return true;
}

// Collect Form Data
function collectFormData() {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    
    return {
        id: Date.now(),
        type: 'job',
        title: document.getElementById('jobTitle').value.trim(),
        category: document.getElementById('jobCategory').value,
        jobType: document.getElementById('jobType').value,
        location: document.getElementById('jobLocation').value.trim(),
        workMode: document.getElementById('workMode').value,
        description: document.getElementById('jobDescription').value.trim(),
        requirements: formatListItems(document.getElementById('jobRequirements').value),
        responsibilities: formatListItems(document.getElementById('responsibilities').value),
        salaryMin: parseFloat(document.getElementById('salaryMin').value),
        salaryMax: parseFloat(document.getElementById('salaryMax').value),
        salaryPeriod: document.getElementById('salaryPeriod').value,
        benefits: formatListItems(document.getElementById('benefits').value),
        experienceLevel: document.getElementById('experienceLevel').value,
        applicationDeadline: document.getElementById('applicationDeadline').value,
        applicationEmail: document.getElementById('applicationEmail').value.trim(),
        applicationUrl: document.getElementById('applicationUrl').value.trim(),
        company: user.fullName || 'Company Name',
        postedBy: user.id || user.email,
        postedDate: new Date().toISOString(),
        status: 'active'
    };
}

// Generate Job Preview HTML
function generateJobPreview(jobData) {
    const salary = `$${jobData.salaryMin.toLocaleString()} - $${jobData.salaryMax.toLocaleString()} ${jobData.salaryPeriod}`;
    
    let html = `
        <h3>${jobData.title}</h3>
        <div class="meta-info">
            <span class="meta-tag">${jobData.company}</span>
            <span class="meta-tag">📍 ${jobData.location}</span>
            <span class="meta-tag">💼 ${jobData.jobType}</span>
            <span class="meta-tag">🏢 ${jobData.workMode}</span>
            <span class="meta-tag">📊 ${jobData.experienceLevel}</span>
            <span class="meta-tag">💰 ${salary}</span>
        </div>
    `;

    html += `
        <div class="preview-section">
            <h4>Job Description</h4>
            <p>${jobData.description}</p>
        </div>
    `;

    if (jobData.requirements.length > 0) {
        html += `
            <div class="preview-section">
                <h4>Requirements</h4>
                <ul>
                    ${jobData.requirements.map(req => `<li>${req}</li>`).join('')}
                </ul>
            </div>
        `;
    }

    if (jobData.responsibilities.length > 0) {
        html += `
            <div class="preview-section">
                <h4>Key Responsibilities</h4>
                <ul>
                    ${jobData.responsibilities.map(resp => `<li>${resp}</li>`).join('')}
                </ul>
            </div>
        `;
    }

    if (jobData.benefits.length > 0) {
        html += `
            <div class="preview-section">
                <h4>Benefits & Perks</h4>
                <ul>
                    ${jobData.benefits.map(benefit => `<li>${benefit}</li>`).join('')}
                </ul>
            </div>
        `;
    }

    html += `
        <div class="preview-section">
            <h4>How to Apply</h4>
            <p>Email: <strong>${jobData.applicationEmail}</strong></p>
            ${jobData.applicationUrl ? `<p>Application Link: <a href="${jobData.applicationUrl}" target="_blank">${jobData.applicationUrl}</a></p>` : ''}
            ${jobData.applicationDeadline ? `<p>Application Deadline: <strong>${new Date(jobData.applicationDeadline).toLocaleDateString()}</strong></p>` : ''}
        </div>
    `;

    return html;
}

// Submit Job
function submitJob(event) {
    event.preventDefault();

    if (!validateRequiredFields()) {
        showNotification('Please fill in all required fields!', 'error');
        return;
    }

    const jobData = collectFormData();

    // Get existing jobs for this employer
    let employerJobs = JSON.parse(localStorage.getItem(getUserKey('employerJobs')) || '[]');
    
    // Add new job
    employerJobs.unshift(jobData);
    
    // Save to localStorage
    localStorage.setItem(getUserKey('employerJobs'), JSON.stringify(employerJobs));

    // Update dashboard data
    let employerDashboardData = JSON.parse(localStorage.getItem(getUserKey('employerDashboardData')) || '{}');
    employerDashboardData.postedJobs = employerJobs.length;
    localStorage.setItem(getUserKey('employerDashboardData'), JSON.stringify(employerDashboardData));

    // Record in timeline
    recordActivity('job');

    showNotification('Job posted successfully! 🎉');

    setTimeout(() => {
        window.location.href = 'employer-my-posts.html';
    }, 2000);
}

// Record Activity for Timeline
function recordActivity(type) {
    const today = new Date().toISOString().split('T')[0];
    
    let applicationHistory = JSON.parse(localStorage.getItem(getUserKey('employerApplicationHistory')) || '[]');
    
    let todayEntry = applicationHistory.find(entry => entry.date === today);
    
    if (!todayEntry) {
        todayEntry = {
            date: today,
            jobs: 0,
            internships: 0,
            applications: 0
        };
        applicationHistory.push(todayEntry);
    }
    
    if (type === 'job') {
        todayEntry.jobs++;
    } else if (type === 'internship') {
        todayEntry.internships++;
    }
    
    applicationHistory.sort((a, b) => new Date(a.date) - new Date(b.date));
    
    if (applicationHistory.length > 30) {
        applicationHistory = applicationHistory.slice(-30);
    }
    
    localStorage.setItem(getUserKey('employerApplicationHistory'), JSON.stringify(applicationHistory));
}

// Show Notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    const bgColor = type === 'error' ? '#f44336' : '#4CAF50';
    
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 30px;
        background: ${bgColor};
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        z-index: 3000;
        animation: slideIn 0.3s ease;
        font-weight: 600;
        max-width: 350px;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Logout User
function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    }
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    const modal = document.getElementById('previewModal');
    if (e.target === modal) {
        closePreview();
    }
});

// Close modal and sidebar with Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePreview();
        const sidebar = document.getElementById('sidebar');
        if (sidebar.classList.contains('active')) {
            toggleSidebar();
        }
    }
});

// Close sidebar when clicking on a link
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.sidebar-link').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                toggleSidebar();
            }
        });
    });
});

// Check if user is logged in and is an employer
window.addEventListener('load', function() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (!token) {
        alert('Please login to post a job');
        window.location.href = 'index.html';
    } else {
        const userData = JSON.parse(user);
        
        if (userData.role !== 'employee') {
            alert('Only employers can post jobs. Redirecting...');
            window.location.href = 'dashboard.html';
        }
    }
});

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100px);
        }
    }
`;
document.head.appendChild(style);