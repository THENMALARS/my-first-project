// Initialize profile data from localStorage
let profileData = {
    name: 'Your Name',
    specialization: 'Your specializations (e.g. Web developer)',
    about: 'Tell us about yourself, your experience, and what you\'re looking for...',
    skills: [],
    avatar: 'https://via.placeholder.com/150'
};

let skillsArray = [];

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// Close sidebar when clicking on a link
document.querySelectorAll('.sidebar-link').forEach(link => {
    link.addEventListener('click', function(e) {
        // Don't close for Edit Profile as it needs to trigger edit mode
        if (!this.getAttribute('onclick')) {
            toggleSidebar();
        }
    });
});

// Toggle Edit Mode
function toggleEditMode() {
    const editBtn = document.getElementById('editBtn');
    const saveBtn = document.getElementById('saveBtn');
    const cancelBtn = document.getElementById('cancelBtn');
    
    // Hide display sections
    document.getElementById('aboutDisplay').style.display = 'none';
    document.getElementById('skillsDisplay').style.display = 'none';
    
    // Show edit sections
    document.getElementById('aboutEdit').style.display = 'block';
    document.getElementById('skillsEdit').style.display = 'block';
    
    // Show avatar upload
    document.getElementById('avatarUploadLabel').style.display = 'block';
    
    // Toggle buttons
    editBtn.style.display = 'none';
    saveBtn.style.display = 'inline-block';
    cancelBtn.style.display = 'inline-block';
    
    // Load current data into edit fields
    document.getElementById('aboutTextarea').value = profileData.about;
    loadSkillsForEdit();
}

// Show Edit Mode (called from sidebar)
function showEditMode() {
    toggleSidebar();
    toggleEditMode();
}

// Cancel Edit
function cancelEdit() {
    const editBtn = document.getElementById('editBtn');
    const saveBtn = document.getElementById('saveBtn');
    const cancelBtn = document.getElementById('cancelBtn');
    
    // Show display sections
    document.getElementById('aboutDisplay').style.display = 'block';
    document.getElementById('skillsDisplay').style.display = 'block';
    
    // Hide edit sections
    document.getElementById('aboutEdit').style.display = 'none';
    document.getElementById('skillsEdit').style.display = 'none';
    
    // Hide avatar upload
    document.getElementById('avatarUploadLabel').style.display = 'none';
    
    // Toggle buttons
    editBtn.style.display = 'inline-block';
    saveBtn.style.display = 'none';
    cancelBtn.style.display = 'none';
    
    // Reset to saved data
    loadProfile();
}

// Save Profile
function saveProfile() {
    // Get values
    profileData.about = document.getElementById('aboutTextarea').value;
    profileData.skills = skillsArray;
    
    // Save to localStorage
    localStorage.setItem('profileData', JSON.stringify(profileData));
    
    // Update display
    loadProfile();
    
    // Exit edit mode
    const editBtn = document.getElementById('editBtn');
    const saveBtn = document.getElementById('saveBtn');
    const cancelBtn = document.getElementById('cancelBtn');
    
    // Show display sections
    document.getElementById('aboutDisplay').style.display = 'block';
    document.getElementById('skillsDisplay').style.display = 'block';
    
    // Hide edit sections
    document.getElementById('aboutEdit').style.display = 'none';
    document.getElementById('skillsEdit').style.display = 'none';
    
    // Hide avatar upload
    document.getElementById('avatarUploadLabel').style.display = 'none';
    
    // Toggle buttons
    editBtn.style.display = 'inline-block';
    saveBtn.style.display = 'none';
    cancelBtn.style.display = 'none';
    
    // Show success message
    alert('Profile saved successfully!');
}

// Load Profile Data
function loadProfile() {
    // Try to get from localStorage
    const saved = localStorage.getItem('profileData');
    if (saved) {
        profileData = JSON.parse(saved);
    }
    
    // Try to get user data from login
    const user = localStorage.getItem('user');
    if (user) {
        const userData = JSON.parse(user);
        profileData.name = userData.fullName || profileData.name;
    }
    
    // Update display
    document.getElementById('profileName').textContent = profileData.name;
    document.getElementById('profileSpecialization').textContent = profileData.specialization;
    document.getElementById('aboutText').textContent = profileData.about;
    document.getElementById('avatarImg').src = profileData.avatar;
    
    // Load skills
    skillsArray = profileData.skills || [];
    displaySkills();
}

// Display Skills
function displaySkills() {
    const skillsList = document.getElementById('skillsList');
    
    if (skillsArray.length === 0) {
        skillsList.innerHTML = '<span class="skill-tag">Add your skills</span>';
    } else {
        skillsList.innerHTML = skillsArray.map(skill => 
            `<span class="skill-tag">${skill}</span>`
        ).join('');
    }
}

// Load Skills for Edit
function loadSkillsForEdit() {
    const skillsEditList = document.getElementById('skillsEditList');
    
    skillsEditList.innerHTML = skillsArray.map((skill, index) => 
        `<div class="skill-tag-edit">
            ${skill}
            <button class="remove-skill" onclick="removeSkill(${index})">×</button>
        </div>`
    ).join('');
}

// Add Skill (Enter key)
document.getElementById('skillInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        const skill = this.value.trim();
        
        if (skill && !skillsArray.includes(skill)) {
            skillsArray.push(skill);
            loadSkillsForEdit();
            this.value = '';
        }
    }
});

// Remove Skill
function removeSkill(index) {
    skillsArray.splice(index, 1);
    loadSkillsForEdit();
}

// Preview Avatar
function previewAvatar(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('avatarImg').src = e.target.result;
            profileData.avatar = e.target.result;
        };
        reader.readAsDataURL(file);
    }
}

// Logout User
function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    }
}

// Sidebar Navigation
document.querySelectorAll('.sidebar-link').forEach(link => {
    link.addEventListener('click', function(e) {
        // Remove active class from all links
        document.querySelectorAll('.sidebar-link').forEach(l => {
            l.classList.remove('active');
        });
        
        // Add active class to clicked link
        this.classList.add('active');
    });
});

// Check if user is logged in
window.addEventListener('load', function() {
    const token = localStorage.getItem('token');
    
    if (!token) {
        // Redirect to home if not logged in
        alert('Please login to view your profile');
        window.location.href = 'index.html';
    } else {
        // Load profile
        loadProfile();
    }
});