// Helper function to get user-specific key
function getUserKey(baseKey) {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const userId = user.id || user.email || 'default';
    return `${baseKey}_${userId}`;
}

let isEditMode = false;
let originalData = null;

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// Load Profile Data
function loadProfile() {
    const profileData = JSON.parse(localStorage.getItem(getUserKey('companyProfileData')) || '{}');
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    
    // Set defaults if no data
    const profile = {
        companyName: profileData.companyName || user.fullName || 'Company Name',
        industry: profileData.industry || '',
        companySize: profileData.companySize || '',
        founded: profileData.founded || '',
        website: profileData.website || '',
        location: profileData.location || '',
        about: profileData.about || '',
        culture: profileData.culture || '',
        email: profileData.email || user.email || '',
        phone: profileData.phone || '',
        linkedin: profileData.linkedin || '',
        logo: profileData.logo || 'https://via.placeholder.com/150?text=Logo'
    };
    
    // Display logo
    document.getElementById('companyLogo').src = profile.logo;
    
    // Display company info
    document.getElementById('displayCompanyName').textContent = profile.companyName || '-';
    document.getElementById('displayIndustry').textContent = profile.industry || '-';
    document.getElementById('displaySize').textContent = profile.companySize ? profile.companySize + ' employees' : '-';
    document.getElementById('displayFounded').textContent = profile.founded || '-';
    document.getElementById('displayWebsite').textContent = profile.website || '-';
    document.getElementById('displayLocation').textContent = profile.location || '-';
    
    // Display about and culture
    document.getElementById('displayAbout').textContent = profile.about || 'Tell job seekers about your company, mission, and values...';
    document.getElementById('displayCulture').textContent = profile.culture || 'Share your company culture and core values...';
    
    // Display contact info
    document.getElementById('displayEmail').textContent = profile.email || '-';
    document.getElementById('displayPhone').textContent = profile.phone || '-';
    document.getElementById('displayLinkedin').textContent = profile.linkedin || '-';
    
    // Store original data
    originalData = profile;
}

// Toggle Edit Mode
function toggleEditMode() {
    isEditMode = !isEditMode;
    
    if (isEditMode) {
        enterEditMode();
    } else {
        exitEditMode();
    }
}

// Enter Edit Mode
function enterEditMode() {
    // Show edit sections, hide display sections
    document.querySelectorAll('.info-display').forEach(el => el.style.display = 'none');
    document.querySelectorAll('.info-edit').forEach(el => el.style.display = 'block');
    
    // Show logo upload section and action buttons
    document.getElementById('logoUploadSection').style.display = 'block';
    document.getElementById('actionButtons').style.display = 'flex';
    
    // Change button text
    document.getElementById('editModeBtn').innerHTML = '<span>❌</span> Cancel';
    
    // Populate edit fields with current data
    document.getElementById('companyName').value = originalData.companyName;
    document.getElementById('industry').value = originalData.industry;
    document.getElementById('companySize').value = originalData.companySize;
    document.getElementById('founded').value = originalData.founded;
    document.getElementById('website').value = originalData.website;
    document.getElementById('location').value = originalData.location;
    document.getElementById('about').value = originalData.about;
    document.getElementById('culture').value = originalData.culture;
    document.getElementById('email').value = originalData.email;
    document.getElementById('phone').value = originalData.phone;
    document.getElementById('linkedin').value = originalData.linkedin;
}

// Exit Edit Mode
function exitEditMode() {
    // Show display sections, hide edit sections
    document.querySelectorAll('.info-display').forEach(el => el.style.display = 'block');
    document.querySelectorAll('.info-edit').forEach(el => el.style.display = 'none');
    
    // Hide logo upload section and action buttons
    document.getElementById('logoUploadSection').style.display = 'none';
    document.getElementById('actionButtons').style.display = 'none';
    
    // Change button text back
    document.getElementById('editModeBtn').innerHTML = '<span>✏️</span> Edit Profile';
    
    isEditMode = false;
}

// Preview Logo
function previewLogo(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('companyLogo').src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
}

// Save Profile
function saveProfile() {
    // Validate required fields
    const requiredFields = ['companyName', 'industry', 'companySize', 'location', 'email'];
    for (const field of requiredFields) {
        const element = document.getElementById(field);
        if (!element.value.trim()) {
            showNotification('Please fill in all required fields!', 'error');
            element.focus();
            return;
        }
    }
    
    // Validate email
    const email = document.getElementById('email').value;
    if (!isValidEmail(email)) {
        showNotification('Please enter a valid email address!', 'error');
        document.getElementById('email').focus();
        return;
    }
    
    // Collect profile data
    const profileData = {
        companyName: document.getElementById('companyName').value.trim(),
        industry: document.getElementById('industry').value,
        companySize: document.getElementById('companySize').value,
        founded: document.getElementById('founded').value,
        website: document.getElementById('website').value.trim(),
        location: document.getElementById('location').value.trim(),
        about: document.getElementById('about').value.trim(),
        culture: document.getElementById('culture').value.trim(),
        email: email,
        phone: document.getElementById('phone').value.trim(),
        linkedin: document.getElementById('linkedin').value.trim(),
        logo: document.getElementById('companyLogo').src
    };
    
    // Save to localStorage
    localStorage.setItem(getUserKey('companyProfileData'), JSON.stringify(profileData));
    
    // Update original data
    originalData = profileData;
    
    // Reload display
    loadProfile();
    
    // Exit edit mode
    exitEditMode();
    
    showNotification('Profile saved successfully! ✅', 'success');
}

// Cancel Edit
function cancelEdit() {
    if (confirm('Discard all changes?')) {
        // Reset logo to original
        document.getElementById('companyLogo').src = originalData.logo;
        
        // Exit edit mode
        exitEditMode();
        toggleEditMode(); // Toggle back the edit mode flag
    }
}

// Validate Email
function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Show Notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    const bgColor = type === 'error' ? '#f44336' : '#4CAF50';
    
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 30px;
        background: ${bgColor};
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        z-index: 3000;
        animation: slideIn 0.3s ease;
        font-weight: 600;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => document.body.removeChild(notification), 300);
    }, 3000);
}

// Logout
function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    }
}

// Check auth on page load
window.addEventListener('load', function() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (!token) {
        alert('Please login to view your profile');
        window.location.href = 'index.html';
    } else {
        const userData = JSON.parse(user);
        if (userData.role !== 'employee') {
            alert('This page is only for employers. Redirecting...');
            window.location.href = 'dashboard.html';
        } else {
            loadProfile();
        }
    }
});

// Add animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn { from { opacity: 0; transform: translateX(100px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slideOut { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(100px); } }
`;
document.head.appendChild(style);