// Dashboard Data
let dashboardData = {
    appliedJobs: 0,
    appliedInternships: 0,
    applicationHistory: []
};
let statsChart = null;

// Helper function to get user-specific key
function getUserKey(baseKey) {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const userId = user.id || user.email || 'default';
    return `${baseKey}_${userId}`;
}

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// Close sidebar when clicking on a link
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.sidebar-link').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                toggleSidebar();
            }
        });
    });
});

// Initialize Application History
function initializeApplicationHistory() {
    const storedHistory = localStorage.getItem(getUserKey('applicationHistory'));
    if (storedHistory) {
        dashboardData.applicationHistory = JSON.parse(storedHistory);
    } else {
        dashboardData.applicationHistory = [];
    }
}

// Add Application to History
function addApplicationToHistory(type) {
    const today = new Date().toISOString().split('T')[0];
    
    let todayEntry = dashboardData.applicationHistory.find(entry => entry.date === today);
    
    if (!todayEntry) {
        todayEntry = {
            date: today,
            jobs: 0,
            internships: 0,
            posts: 0
        };
        dashboardData.applicationHistory.push(todayEntry);
    }
    
    if (type === 'job') {
        todayEntry.jobs++;
    } else if (type === 'internship') {
        todayEntry.internships++;
    } else if (type === 'post') {
        todayEntry.posts++;
    }
    
    dashboardData.applicationHistory.sort((a, b) => new Date(a.date) - new Date(b.date));
    
    if (dashboardData.applicationHistory.length > 30) {
        dashboardData.applicationHistory = dashboardData.applicationHistory.slice(-30);
    }
    
    localStorage.setItem(getUserKey('applicationHistory'), JSON.stringify(dashboardData.applicationHistory));
}

// Get Historical Data for Chart
function getChartData() {
    if (dashboardData.applicationHistory.length === 0) {
        const dates = [];
        const jobsData = [];
        const internshipsData = [];
        const postsData = [];
        
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            dates.push(dateStr);
            jobsData.push(0);
            internshipsData.push(0);
            postsData.push(0);
        }
        
        return { dates, jobsData, internshipsData, postsData };
    }
    
    const recentHistory = dashboardData.applicationHistory.slice(-7);
    
    const dates = recentHistory.map(entry => {
        const date = new Date(entry.date);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    });
    
    const jobsData = recentHistory.map(entry => entry.jobs);
    const internshipsData = recentHistory.map(entry => entry.internships);
    const postsData = recentHistory.map(entry => entry.posts);
    
    return { dates, jobsData, internshipsData, postsData };
}

// Load Dashboard Data
function loadDashboard() {
    const user = localStorage.getItem('user');
    const profileData = localStorage.getItem(getUserKey('profileData'));
    const storedDashboardData = localStorage.getItem(getUserKey('dashboardData'));
    const userPosts = localStorage.getItem(getUserKey('userPosts'));

    if (user) {
        const userData = JSON.parse(user);
        document.getElementById('userName').textContent = userData.fullName || 'Your Name';
    }

    if (profileData) {
        const profile = JSON.parse(profileData);
        document.getElementById('userSpecialization').textContent =
            profile.specialization || 'Add your specialization in Edit Profile';
        if (profile.avatar) {
            document.getElementById('userAvatar').src = profile.avatar;
        }
    }

    if (storedDashboardData) {
        dashboardData = JSON.parse(storedDashboardData);
    }

    let postsCount = 0;
    if (userPosts) {
        const posts = JSON.parse(userPosts);
        postsCount = posts.length;
    }

    initializeApplicationHistory();
    updateDashboardCounts(postsCount);
    createChart(postsCount);
}

// Update Dashboard Counts
function updateDashboardCounts(postsCount) {
    document.getElementById('appliedJobsCount').textContent = dashboardData.appliedJobs;
    document.getElementById('appliedInternshipsCount').textContent = dashboardData.appliedInternships;
    document.getElementById('statJobsCount').textContent = dashboardData.appliedJobs;
    document.getElementById('statInternshipsCount').textContent = dashboardData.appliedInternships;
    document.getElementById('statPostsCount').textContent = postsCount;
}

// Create Statistics Chart (Line Chart)
function createChart(postsCount) {
    const ctx = document.getElementById('statsChart');

    if (statsChart) {
        statsChart.destroy();
    }

    const chartData = getChartData();

    statsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: chartData.dates,
            datasets: [
                {
                    label: 'Jobs Applied',
                    data: chartData.jobsData,
                    borderColor: 'rgba(102, 126, 234, 1)',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderWidth: 3,
                    pointRadius: 5,
                    pointBackgroundColor: 'rgba(102, 126, 234, 1)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointHoverRadius: 7,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Internships Applied',
                    data: chartData.internshipsData,
                    borderColor: 'rgba(240, 147, 251, 1)',
                    backgroundColor: 'rgba(240, 147, 251, 0.1)',
                    borderWidth: 3,
                    pointRadius: 5,
                    pointBackgroundColor: 'rgba(240, 147, 251, 1)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointHoverRadius: 7,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Posts Created',
                    data: chartData.postsData,
                    borderColor: 'rgba(79, 172, 254, 1)',
                    backgroundColor: 'rgba(79, 172, 254, 0.1)',
                    borderWidth: 3,
                    pointRadius: 5,
                    pointBackgroundColor: 'rgba(79, 172, 254, 1)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointHoverRadius: 7,
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        font: { size: 12, weight: 'bold' },
                        color: '#1a3a52',
                        padding: 15,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                title: {
                    display: true,
                    text: 'Activity Timeline (Last 7 Days)',
                    font: { size: 16, weight: 'bold' },
                    color: '#1a3a52',
                    padding: { bottom: 20 }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    padding: 12,
                    displayColors: true,
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            label += context.parsed.y;
                            return label;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        font: { size: 12 },
                        color: '#5a6a7a'
                    },
                    grid: {
                        color: 'rgba(26, 58, 82, 0.1)',
                        drawBorder: false
                    },
                    title: {
                        display: true,
                        text: 'Number of Applications',
                        color: '#1a3a52',
                        font: { size: 13, weight: 'bold' }
                    }
                },
                x: {
                    ticks: {
                        font: { size: 11, weight: '600' },
                        color: '#1a3a52'
                    },
                    grid: { display: false },
                    title: {
                        display: true,
                        text: 'Date',
                        color: '#1a3a52',
                        font: { size: 13, weight: 'bold' }
                    }
                }
            }
        }
    });
}

// Logout User
function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    }
}

// Sidebar Navigation
document.querySelectorAll('.sidebar-link').forEach(link => {
    link.addEventListener('click', function(e) {
        document.querySelectorAll('.sidebar-link').forEach(l => {
            l.classList.remove('active');
        });
        this.classList.add('active');
    });
});

// Check if user is logged in
window.addEventListener('load', function() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (!token) {
        alert('Please login to view your dashboard');
        window.location.href = 'index.html';
    } else {
        const userData = JSON.parse(user);
        
        // Check if user is job seeker
        if (userData.role !== 'jobseeker') {
            alert('This page is only for job seekers. Redirecting to employer dashboard...');
            window.location.href = 'employer-dashboard.html';
        } else {
            loadDashboard();
        }
    }
});

window.recordApplication = function(type) {
    addApplicationToHistory(type);
};