// =============================================
// MY APPLICATIONS - JOB SEEKER
// =============================================

// Sample data (replace with actual API calls)
let myApplications = [
    {
        id: 1,
        position: "Senior Frontend Developer",
        company: "TechCorp Inc.",
        companyLogo: "https://via.placeholder.com/80?text=TC",
        location: "San Francisco, CA",
        type: "job",
        appliedDate: "2025-02-05",
        status: "shortlisted",
        description: "We are looking for an experienced Frontend Developer to join our growing team...",
        salary: "$120,000 - $150,000",
        resumeSubmitted: "john_doe_resume.pdf",
        coverLetter: "I am excited to apply for the Senior Frontend Developer position at TechCorp. With 5 years of experience in React and modern web technologies, I believe I would be a great addition to your team...",
        timeline: [
            { status: "Applied", date: "2025-02-05", message: "Your application has been received" },
            { status: "Reviewed", date: "2025-02-06", message: "Your application is under review" },
            { status: "Shortlisted", date: "2025-02-08", message: "Congratulations! You've been shortlisted. We will contact you soon for the next steps." }
        ]
    },
    {
        id: 2,
        position: "Backend Developer Internship",
        company: "StartupHub",
        companyLogo: "https://via.placeholder.com/80?text=SH",
        location: "Remote",
        type: "internship",
        appliedDate: "2025-02-06",
        status: "interview",
        description: "Join our dynamic team as a Backend Developer intern and gain hands-on experience...",
        salary: "$2,000/month",
        resumeSubmitted: "john_doe_resume.pdf",
        coverLetter: "I am writing to express my interest in the Backend Developer Internship at StartupHub...",
        timeline: [
            { status: "Applied", date: "2025-02-06", message: "Your application has been received" },
            { status: "Reviewed", date: "2025-02-07", message: "Your application is under review" },
            { status: "Interview Scheduled", date: "2025-02-09", message: "We would like to schedule an interview with you. Please check your email for details." }
        ]
    },
    {
        id: 3,
        position: "Full Stack Developer",
        company: "WebSolutions Ltd.",
        companyLogo: "https://via.placeholder.com/80?text=WS",
        location: "New York, NY",
        type: "job",
        appliedDate: "2025-02-07",
        status: "reviewed",
        description: "Seeking a talented Full Stack Developer to work on exciting projects...",
        salary: "$100,000 - $130,000",
        resumeSubmitted: "john_doe_resume.pdf",
        coverLetter: "I am thrilled to apply for the Full Stack Developer position...",
        timeline: [
            { status: "Applied", date: "2025-02-07", message: "Your application has been received" },
            { status: "Reviewed", date: "2025-02-08", message: "Your application is currently being reviewed by our hiring team" }
        ]
    },
    {
        id: 4,
        position: "React Developer",
        company: "Digital Agency",
        companyLogo: "https://via.placeholder.com/80?text=DA",
        location: "Austin, TX",
        type: "job",
        appliedDate: "2025-02-01",
        status: "rejected",
        description: "Looking for a React specialist to build cutting-edge web applications...",
        salary: "$90,000 - $110,000",
        resumeSubmitted: "john_doe_resume.pdf",
        coverLetter: "I am writing to apply for the React Developer position at Digital Agency...",
        timeline: [
            { status: "Applied", date: "2025-02-01", message: "Your application has been received" },
            { status: "Reviewed", date: "2025-02-03", message: "Your application is under review" },
            { status: "Not Selected", date: "2025-02-08", message: "Thank you for your interest. After careful consideration, we have decided to move forward with other candidates. We wish you the best in your job search." }
        ]
    },
    {
        id: 5,
        position: "UI/UX Designer Intern",
        company: "Creative Studio",
        companyLogo: "https://via.placeholder.com/80?text=CS",
        location: "Los Angeles, CA",
        type: "internship",
        appliedDate: "2025-02-08",
        status: "new",
        description: "Join our creative team to design beautiful and intuitive user interfaces...",
        salary: "$1,500/month",
        resumeSubmitted: "john_doe_resume.pdf",
        coverLetter: "I am excited to apply for the UI/UX Designer Internship at Creative Studio...",
        timeline: [
            { status: "Applied", date: "2025-02-08", message: "Your application has been received and is pending review" }
        ]
    }
];

let currentFilter = 'all';
let currentTypeFilter = 'all';
let currentApplication = null;

// =============================================
// INITIALIZATION
// =============================================

document.addEventListener('DOMContentLoaded', function() {
    loadApplications();
    updateCounts();
    updateStats();
});

// =============================================
// SIDEBAR FUNCTIONS
// =============================================

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// =============================================
// LOAD APPLICATIONS
// =============================================

function loadApplications() {
    const container = document.getElementById('applicationsContainer');
    const emptyState = document.getElementById('emptyState');
    
    // Filter applications
    let filteredApps = myApplications;
    
    // Filter by status
    if (currentFilter !== 'all') {
        filteredApps = filteredApps.filter(app => app.status === currentFilter);
    }
    
    // Filter by type
    if (currentTypeFilter !== 'all') {
        filteredApps = filteredApps.filter(app => app.type === currentTypeFilter);
    }
    
    // Check if empty
    if (filteredApps.length === 0) {
        container.style.display = 'none';
        emptyState.style.display = 'block';
        return;
    }
    
    container.style.display = 'grid';
    emptyState.style.display = 'none';
    
    // Render applications
    container.innerHTML = filteredApps.map(app => `
        <div class="application-card" onclick="viewApplication(${app.id})">
            <div class="card-header">
                <img src="${app.companyLogo}" alt="${app.company}" class="company-logo-small">
                <div class="card-title">
                    <div class="position-title">${app.position}</div>
                    <div class="company-name">${app.company}</div>
                </div>
            </div>
            
            <div class="card-meta">
                <span>📍 ${app.location}</span>
                <span>💼 ${app.type === 'job' ? 'Job' : 'Internship'}</span>
            </div>
            
            <div class="card-footer">
                <span class="applied-date">Applied: ${formatDate(app.appliedDate)}</span>
                <div class="status-badge ${app.status}">${formatStatus(app.status)}</div>
            </div>
        </div>
    `).join('');
}

// =============================================
// FILTER FUNCTIONS
// =============================================

function filterByStatus(status) {
    currentFilter = status;
    
    // Update active tab
    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    event.target.classList.add('active');
    
    loadApplications();
}

function filterByType() {
    const select = document.getElementById('typeFilter');
    currentTypeFilter = select.value;
    loadApplications();
}

function searchApplications() {
    const searchTerm = document.getElementById('searchApplication').value.toLowerCase();
    const cards = document.querySelectorAll('.application-card');
    
    cards.forEach(card => {
        const position = card.querySelector('.position-title').textContent.toLowerCase();
        const company = card.querySelector('.company-name').textContent.toLowerCase();
        
        if (position.includes(searchTerm) || company.includes(searchTerm)) {
            card.style.display = 'flex';
        } else {
            card.style.display = 'none';
        }
    });
}

// =============================================
// UPDATE COUNTS & STATS
// =============================================

function updateCounts() {
    const total = myApplications.length;
    const newCount = myApplications.filter(app => app.status === 'new').length;
    const reviewed = myApplications.filter(app => app.status === 'reviewed').length;
    const shortlisted = myApplications.filter(app => app.status === 'shortlisted').length;
    const interview = myApplications.filter(app => app.status === 'interview').length;
    const rejected = myApplications.filter(app => app.status === 'rejected').length;
    
    document.getElementById('countAll').textContent = total;
    document.getElementById('countNew').textContent = newCount;
    document.getElementById('countReviewed').textContent = reviewed;
    document.getElementById('countShortlisted').textContent = shortlisted;
    document.getElementById('countInterview').textContent = interview;
    document.getElementById('countRejected').textContent = rejected;
}

function updateStats() {
    const total = myApplications.length;
    const inProgress = myApplications.filter(app => 
        app.status === 'new' || app.status === 'reviewed' || app.status === 'interview'
    ).length;
    const shortlisted = myApplications.filter(app => app.status === 'shortlisted').length;
    
    document.getElementById('totalApplications').textContent = total;
    document.getElementById('inProgressApplications').textContent = inProgress;
    document.getElementById('shortlistedApplications').textContent = shortlisted;
}

// =============================================
// VIEW APPLICATION MODAL
// =============================================

function viewApplication(applicationId) {
    const application = myApplications.find(app => app.id === applicationId);
    if (!application) return;
    
    currentApplication = application;
    
    // Populate modal
    document.getElementById('modalPosition').textContent = application.position;
    document.getElementById('modalCompany').textContent = application.company;
    document.getElementById('modalCompanyLogo').src = application.companyLogo;
    document.getElementById('modalType').textContent = application.type === 'job' ? 'Full-time Job' : 'Internship';
    document.getElementById('modalLocation').textContent = application.location;
    
    // Status badge
    const statusBadge = document.getElementById('modalStatusBadge');
    statusBadge.textContent = formatStatus(application.status);
    statusBadge.className = `status-badge ${application.status}`;
    
    // Details
    document.getElementById('detailPosition').textContent = application.position;
    document.getElementById('detailCompany').textContent = application.company;
    document.getElementById('detailLocation').textContent = application.location;
    document.getElementById('detailType').textContent = application.type === 'job' ? 'Full-time Job' : 'Internship';
    document.getElementById('detailDescription').textContent = application.description;
    document.getElementById('detailAppliedDate').textContent = formatDate(application.appliedDate);
    document.getElementById('detailResume').textContent = application.resumeSubmitted;
    document.getElementById('detailCoverLetter').textContent = application.coverLetter;
    
    // Timeline
    renderTimeline(application.timeline);
    
    // Show/hide status updates section
    const hasMessages = application.timeline.length > 1;
    if (hasMessages) {
        document.getElementById('statusUpdatesSection').style.display = 'block';
        renderMessages(application.timeline);
    } else {
        document.getElementById('statusUpdatesSection').style.display = 'none';
    }
    
    // Show modal
    document.getElementById('applicationModal').classList.add('active');
}

function closeApplicationModal() {
    document.getElementById('applicationModal').classList.remove('active');
    currentApplication = null;
}

// =============================================
// RENDER TIMELINE
// =============================================

function renderTimeline(timeline) {
    const container = document.getElementById('applicationTimeline');
    
    container.innerHTML = timeline.map(item => `
        <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <div class="timeline-status">${item.status}</div>
                <div class="timeline-date">${formatDate(item.date)}</div>
                <div class="timeline-message">${item.message}</div>
            </div>
        </div>
    `).join('');
}

// =============================================
// RENDER MESSAGES
// =============================================

function renderMessages(timeline) {
    const container = document.getElementById('employerMessages');
    
    // Filter timeline items that have meaningful messages
    const messages = timeline.filter(item => 
        item.status !== 'Applied' && item.message && item.message.length > 30
    );
    
    if (messages.length === 0) {
        container.innerHTML = '<p style="color: var(--text-light, #999);">No messages from employer yet.</p>';
        return;
    }
    
    container.innerHTML = messages.map(msg => `
        <div class="message-item">
            <div class="message-header">
                <span class="message-status">${msg.status}</span>
                <span class="message-date">${formatDate(msg.date)}</span>
            </div>
            <div class="message-content">${msg.message}</div>
        </div>
    `).join('');
}

// =============================================
// ACTION FUNCTIONS
// =============================================

function viewJobPosting() {
    if (!currentApplication) return;
    
    // In production, redirect to the actual job posting page
    showToast('Opening job posting...');
    
    // Example: window.location.href = `job-details.html?id=${currentApplication.jobId}`;
    console.log('View job posting:', currentApplication);
}

function contactEmployer() {
    if (!currentApplication) return;
    
    // In production, open email client or contact form
    const subject = encodeURIComponent(`Regarding ${currentApplication.position} Application`);
    const body = encodeURIComponent(`Dear Hiring Manager,\n\nI am writing regarding my application for the ${currentApplication.position} position at ${currentApplication.company}.\n\nBest regards`);
    
    // This will open the user's default email client
    window.location.href = `mailto:hr@${currentApplication.company.toLowerCase().replace(/\s+/g, '')}.com?subject=${subject}&body=${body}`;
    
    showToast('Opening email client...');
}

function withdrawApplication() {
    if (!currentApplication) return;
    
    if (confirm(`Are you sure you want to withdraw your application for ${currentApplication.position} at ${currentApplication.company}?`)) {
        // Remove from array
        myApplications = myApplications.filter(app => app.id !== currentApplication.id);
        
        // Update UI
        loadApplications();
        updateCounts();
        updateStats();
        closeApplicationModal();
        
        showToast('Application withdrawn successfully');
        
        // In production, call API to withdraw application
        /*
        fetch(`/api/applications/${currentApplication.id}/withdraw`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('userToken')}`
            }
        });
        */
    }
}

// =============================================
// UTILITY FUNCTIONS
// =============================================

function formatStatus(status) {
    const statusMap = {
        'new': 'Applied',
        'reviewed': 'Reviewed',
        'shortlisted': 'Shortlisted',
        'interview': 'Interview',
        'rejected': 'Not Selected',
        'hired': 'Hired'
    };
    return statusMap[status] || status;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const options = { month: 'short', day: 'numeric', year: 'numeric' };
    return date.toLocaleDateString('en-US', options);
}

function showToast(message) {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    toastMessage.textContent = message;
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// =============================================
// LOGOUT FUNCTION
// =============================================

function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('userToken');
        localStorage.removeItem('userData');
        window.location.href = 'index.html';
    }
}

// =============================================
// LOAD APPLICATIONS FROM BACKEND (EXAMPLE)
// =============================================

/*
// Example function to load applications from your backend API
async function loadApplicationsFromAPI() {
    try {
        const token = localStorage.getItem('userToken');
        const response = await fetch('/api/jobseeker/my-applications', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            myApplications = data.applications;
            loadApplications();
            updateCounts();
            updateStats();
        }
    } catch (error) {
        console.error('Error loading applications:', error);
    }
}

// Call it on page load
document.addEventListener('DOMContentLoaded', function() {
    loadApplicationsFromAPI();
});
*/

// =============================================
// REAL-TIME NOTIFICATIONS (OPTIONAL)
// =============================================

/*
// Example: Listen for real-time status updates using WebSocket or polling
function setupRealTimeUpdates() {
    // Using WebSocket
    const ws = new WebSocket('ws://localhost:5000/notifications');
    
    ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        
        if (data.type === 'application_status_update') {
            // Update the application in the list
            const appIndex = myApplications.findIndex(app => app.id === data.applicationId);
            if (appIndex !== -1) {
                myApplications[appIndex].status = data.newStatus;
                myApplications[appIndex].timeline.push({
                    status: data.statusLabel,
                    date: new Date().toISOString(),
                    message: data.message
                });
                
                // Refresh UI
                loadApplications();
                updateCounts();
                updateStats();
                
                // Show notification
                showToast(`Status updated: ${data.statusLabel}`);
            }
        }
    };
    
    // Or using polling
    setInterval(async () => {
        const token = localStorage.getItem('userToken');
        const response = await fetch('/api/jobseeker/check-updates', {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (response.ok) {
            const data = await response.json();
            if (data.hasUpdates) {
                loadApplicationsFromAPI();
            }
        }
    }, 30000); // Check every 30 seconds
}
*/