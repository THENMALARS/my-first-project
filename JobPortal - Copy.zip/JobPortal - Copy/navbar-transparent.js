// Transparent Navbar for Homepage (index.html) Only
(function() {
    // Check if we're on the homepage
    const isHomepage = window.location.pathname === '/' || 
                       window.location.pathname.endsWith('index.html') ||
                       window.location.pathname === '/index.html';
    
    if (isHomepage) {
        // Wait for DOM to load
        document.addEventListener('DOMContentLoaded', function() {
            const navbar = document.querySelector('.navbar');
            
            if (navbar) {
                // Add transparent class to navbar
                navbar.classList.add('navbar-transparent');
                document.body.classList.add('has-transparent-navbar');
                
                // Add scroll effect - navbar becomes solid when scrolling
                let lastScroll = 0;
                
                window.addEventListener('scroll', function() {
                    const currentScroll = window.pageYOffset;
                    
                    if (currentScroll > 100) {
                        navbar.classList.add('scrolled');
                    } else {
                        navbar.classList.remove('scrolled');
                    }
                    
                    lastScroll = currentScroll;
                });
            }
        });
    }
})();