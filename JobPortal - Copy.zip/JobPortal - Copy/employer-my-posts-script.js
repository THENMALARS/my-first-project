// Helper function to get user-specific key
function getUserKey(baseKey) {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const userId = user.id || user.email || 'default';
    return `${baseKey}_${userId}`;
}

let allPosts = [];
let currentFilter = 'all';
let currentPost = null;

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// Load All Posts
function loadPosts() {
    const jobs = JSON.parse(localStorage.getItem(getUserKey('employerJobs')) || '[]');
    const internships = JSON.parse(localStorage.getItem(getUserKey('employerInternships')) || '[]');
    
    allPosts = [...jobs, ...internships].sort((a, b) => 
        new Date(b.postedDate) - new Date(a.postedDate)
    );
    
    updateCounts();
    displayPosts();
}

// Update Counts
function updateCounts() {
    const jobs = allPosts.filter(p => p.type === 'job');
    const internships = allPosts.filter(p => p.type === 'internship');
    
    document.getElementById('countAll').textContent = allPosts.length;
    document.getElementById('countJobs').textContent = jobs.length;
    document.getElementById('countInternships').textContent = internships.length;
}

// Filter Posts
function filterPosts(filter) {
    currentFilter = filter;
    
    // Update active tab
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    displayPosts();
}

// Display Posts
function displayPosts() {
    const grid = document.getElementById('postsGrid');
    const emptyState = document.getElementById('emptyState');
    
    let filteredPosts = allPosts;
    
    if (currentFilter === 'job') {
        filteredPosts = allPosts.filter(p => p.type === 'job');
    } else if (currentFilter === 'internship') {
        filteredPosts = allPosts.filter(p => p.type === 'internship');
    }
    
    if (filteredPosts.length === 0) {
        grid.style.display = 'none';
        emptyState.style.display = 'block';
        return;
    }
    
    grid.style.display = 'grid';
    emptyState.style.display = 'none';
    
    grid.innerHTML = filteredPosts.map(post => createPostCard(post)).join('');
}

// Create Post Card HTML
function createPostCard(post) {
    const date = new Date(post.postedDate).toLocaleDateString();
    const isJob = post.type === 'job';
    
    let metaInfo = '';
    if (isJob) {
        metaInfo = `
            <div class="meta-item"><strong>Type:</strong> ${post.jobType}</div>
            <div class="meta-item"><strong>Location:</strong> ${post.location}</div>
            <div class="meta-item"><strong>Salary:</strong> $${post.salaryMin.toLocaleString()} - $${post.salaryMax.toLocaleString()} ${post.salaryPeriod}</div>
        `;
    } else {
        metaInfo = `
            <div class="meta-item"><strong>Duration:</strong> ${post.duration}</div>
            <div class="meta-item"><strong>Location:</strong> ${post.location}</div>
            <div class="meta-item"><strong>Type:</strong> ${post.internshipType}</div>
        `;
    }
    
    return `
        <div class="post-card" onclick="viewPost(${post.id})">
            <div class="post-type-badge">${isJob ? '💼 Job' : '🎓 Internship'}</div>
            <h3>${post.title}</h3>
            <div class="post-meta">
                ${metaInfo}
            </div>
            <div class="post-footer">
                <span class="post-date">Posted on ${date}</span>
                <button class="view-details-btn" onclick="event.stopPropagation(); viewPost(${post.id})">
                    View Details
                </button>
            </div>
        </div>
    `;
}

// View Post Details
function viewPost(postId) {
    currentPost = allPosts.find(p => p.id === postId);
    if (!currentPost) return;
    
    const details = document.getElementById('postDetails');
    const isJob = currentPost.type === 'job';
    
    let html = `<h2>${currentPost.title}</h2>`;
    
    // Meta tags
    html += '<div class="detail-meta">';
    html += `<span class="detail-tag">${currentPost.company}</span>`;
    html += `<span class="detail-tag">📍 ${currentPost.location}</span>`;
    html += `<span class="detail-tag">🏢 ${currentPost.workMode}</span>`;
    
    if (isJob) {
        html += `<span class="detail-tag">💼 ${currentPost.jobType}</span>`;
        html += `<span class="detail-tag">📊 ${currentPost.experienceLevel}</span>`;
        html += `<span class="detail-tag">💰 $${currentPost.salaryMin.toLocaleString()} - $${currentPost.salaryMax.toLocaleString()} ${currentPost.salaryPeriod}</span>`;
    } else {
        html += `<span class="detail-tag">⏱️ ${currentPost.duration}</span>`;
        html += `<span class="detail-tag">💰 ${currentPost.internshipType}</span>`;
        if (currentPost.stipend) {
            html += `<span class="detail-tag">$${currentPost.stipend.toLocaleString()} ${currentPost.stipendPeriod}</span>`;
        }
    }
    html += '</div>';
    
    // Description
    html += `<div class="detail-section">
        <h3>${isJob ? 'Job' : 'Internship'} Description</h3>
        <p>${currentPost.description}</p>
    </div>`;
    
    // Requirements
    if (currentPost.requirements.length > 0) {
        html += `<div class="detail-section">
            <h3>Requirements</h3>
            <ul>${currentPost.requirements.map(req => `<li>${req}</li>`).join('')}</ul>
        </div>`;
    }
    
    // Responsibilities
    if (currentPost.responsibilities.length > 0) {
        html += `<div class="detail-section">
            <h3>${isJob ? 'Key Responsibilities' : 'What You\'ll Do'}</h3>
            <ul>${currentPost.responsibilities.map(resp => `<li>${resp}</li>`).join('')}</ul>
        </div>`;
    }
    
    // Benefits
    if (currentPost.benefits && currentPost.benefits.length > 0) {
        html += `<div class="detail-section">
            <h3>Benefits & Perks</h3>
            <ul>${currentPost.benefits.map(benefit => `<li>${benefit}</li>`).join('')}</ul>
        </div>`;
    }
    
    // Application info
    html += `<div class="detail-section">
        <h3>Application Information</h3>
        <p><strong>Email:</strong> ${currentPost.applicationEmail}</p>`;
    if (currentPost.applicationUrl) {
        html += `<p><strong>URL:</strong> <a href="${currentPost.applicationUrl}" target="_blank">${currentPost.applicationUrl}</a></p>`;
    }
    if (currentPost.applicationDeadline) {
        html += `<p><strong>Deadline:</strong> ${new Date(currentPost.applicationDeadline).toLocaleDateString()}</p>`;
    }
    html += '</div>';
    
    details.innerHTML = html;
    document.getElementById('postModal').classList.add('active');
}

// Close Post Modal
function closePostModal() {
    document.getElementById('postModal').classList.remove('active');
    currentPost = null;
}

// Start Edit
function startEdit() {
    if (!currentPost) return;
    
    closePostModal();
    
    const isJob = currentPost.type === 'job';
    const editFields = document.getElementById('editFormFields');
    
    let html = '';
    
    if (isJob) {
        html = `
            <div class="form-group">
                <label for="editTitle">Job Title *</label>
                <input type="text" id="editTitle" value="${currentPost.title}" required>
            </div>
            <div class="form-group">
                <label for="editDescription">Description *</label>
                <textarea id="editDescription" rows="5" required>${currentPost.description}</textarea>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="editLocation">Location *</label>
                    <input type="text" id="editLocation" value="${currentPost.location}" required>
                </div>
                <div class="form-group">
                    <label for="editWorkMode">Work Mode *</label>
                    <select id="editWorkMode" required>
                        <option value="On-site" ${currentPost.workMode === 'On-site' ? 'selected' : ''}>On-site</option>
                        <option value="Remote" ${currentPost.workMode === 'Remote' ? 'selected' : ''}>Remote</option>
                        <option value="Hybrid" ${currentPost.workMode === 'Hybrid' ? 'selected' : ''}>Hybrid</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="editSalaryMin">Min Salary ($) *</label>
                    <input type="number" id="editSalaryMin" value="${currentPost.salaryMin}" required>
                </div>
                <div class="form-group">
                    <label for="editSalaryMax">Max Salary ($) *</label>
                    <input type="number" id="editSalaryMax" value="${currentPost.salaryMax}" required>
                </div>
            </div>
            <div class="form-group">
                <label for="editApplicationEmail">Application Email *</label>
                <input type="email" id="editApplicationEmail" value="${currentPost.applicationEmail}" required>
            </div>
        `;
    } else {
        html = `
            <div class="form-group">
                <label for="editTitle">Internship Title *</label>
                <input type="text" id="editTitle" value="${currentPost.title}" required>
            </div>
            <div class="form-group">
                <label for="editDescription">Description *</label>
                <textarea id="editDescription" rows="5" required>${currentPost.description}</textarea>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="editLocation">Location *</label>
                    <input type="text" id="editLocation" value="${currentPost.location}" required>
                </div>
                <div class="form-group">
                    <label for="editDuration">Duration *</label>
                    <input type="text" id="editDuration" value="${currentPost.duration}" required>
                </div>
            </div>
            <div class="form-group">
                <label for="editApplicationEmail">Application Email *</label>
                <input type="email" id="editApplicationEmail" value="${currentPost.applicationEmail}" required>
            </div>
        `;
    }
    
    editFields.innerHTML = html;
    document.getElementById('editModalTitle').textContent = `Edit ${isJob ? 'Job' : 'Internship'}`;
    document.getElementById('editModal').classList.add('active');
}

// Save Edit
function saveEdit(event) {
    event.preventDefault();
    
    if (!currentPost) return;
    
    const isJob = currentPost.type === 'job';
    
    // Update current post
    currentPost.title = document.getElementById('editTitle').value;
    currentPost.description = document.getElementById('editDescription').value;
    currentPost.location = document.getElementById('editLocation').value;
    currentPost.applicationEmail = document.getElementById('editApplicationEmail').value;
    
    if (isJob) {
        currentPost.workMode = document.getElementById('editWorkMode').value;
        currentPost.salaryMin = parseFloat(document.getElementById('editSalaryMin').value);
        currentPost.salaryMax = parseFloat(document.getElementById('editSalaryMax').value);
    } else {
        currentPost.duration = document.getElementById('editDuration').value;
    }
    
    // Save to localStorage
    const storageKey = isJob ? getUserKey('employerJobs') : getUserKey('employerInternships');
    const posts = JSON.parse(localStorage.getItem(storageKey) || '[]');
    const index = posts.findIndex(p => p.id === currentPost.id);
    
    if (index !== -1) {
        posts[index] = currentPost;
        localStorage.setItem(storageKey, JSON.stringify(posts));
    }
    
    showNotification('Post updated successfully! ✅', 'success');
    closeEditModal();
    loadPosts();
    currentPost = null;
}

// Close Edit Modal
function closeEditModal() {
    document.getElementById('editModal').classList.remove('active');
}

// Delete Post
function deletePost() {
    if (!currentPost) return;
    
    if (!confirm(`Are you sure you want to delete this ${currentPost.type}?`)) return;
    
    const isJob = currentPost.type === 'job';
    const storageKey = isJob ? getUserKey('employerJobs') : getUserKey('employerInternships');
    let posts = JSON.parse(localStorage.getItem(storageKey) || '[]');
    
    posts = posts.filter(p => p.id !== currentPost.id);
    localStorage.setItem(storageKey, JSON.stringify(posts));
    
    // Update dashboard counts
    let dashboardData = JSON.parse(localStorage.getItem(getUserKey('employerDashboardData')) || '{}');
    if (isJob) {
        dashboardData.postedJobs = posts.length;
    } else {
        dashboardData.postedInternships = posts.length;
    }
    localStorage.setItem(getUserKey('employerDashboardData'), JSON.stringify(dashboardData));
    
    showNotification('Post deleted successfully! 🗑️', 'success');
    closePostModal();
    loadPosts();
    currentPost = null;
}

// Show Notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    const bgColor = type === 'error' ? '#f44336' : '#4CAF50';
    
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 30px;
        background: ${bgColor};
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        z-index: 3000;
        animation: slideIn 0.3s ease;
        font-weight: 600;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => document.body.removeChild(notification), 300);
    }, 3000);
}

// Logout
function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    }
}

// Check auth and load posts on page load
window.addEventListener('load', function() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (!token) {
        alert('Please login to view your posts');
        window.location.href = 'index.html';
    } else {
        const userData = JSON.parse(user);
        if (userData.role !== 'employee') {
            alert('This page is only for employers. Redirecting...');
            window.location.href = 'dashboard.html';
        } else {
            loadPosts();
        }
    }
});

// Close modals with ESC key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePostModal();
        closeEditModal();
    }
});

// Add animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn { from { opacity: 0; transform: translateX(100px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slideOut { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(100px); } }
`;
document.head.appendChild(style);