// Theme Toggle System - Works across all pages
(function() {
    // Apply saved theme IMMEDIATELY (before page renders)
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initThemeToggle);
    } else {
        initThemeToggle();
    }
    
    function initThemeToggle() {
        // Find the navbar navigation container
        const navRight = document.querySelector('.nav-right') || document.querySelector('.nav-links');
        
        if (!navRight) {
            console.warn('No nav-right or nav-links found');
            return;
        }
        
        // Check if toggle already exists
        if (document.querySelector('.theme-toggle-wrapper')) {
            return;
        }
        
        // Find and remove the "Posts" link
        const postsLink = Array.from(navRight.querySelectorAll('a')).find(a => {
            const text = a.textContent.trim().toLowerCase();
            return text === 'posts' || text === 'post';
        });
        
        // Create theme toggle HTML
        const themeToggleHTML = `
            <div class="theme-toggle-wrapper">
                <div class="theme-toggle" onclick="toggleTheme()" title="Toggle Dark/Light Mode">
                    <span class="theme-icon sun">☀️</span>
                    <span class="theme-icon moon">🌙</span>
                    <div class="theme-toggle-slider"></div>
                </div>
            </div>
        `;
        
        if (postsLink) {
            // Replace Posts link with theme toggle
            const wrapper = document.createElement('div');
            wrapper.innerHTML = themeToggleHTML;
            postsLink.parentNode.replaceChild(wrapper.firstElementChild, postsLink);
        } else {
            // Add theme toggle before Sign in button
            const signInBtn = navRight.querySelector('.signin-btn');
            const wrapper = document.createElement('div');
            wrapper.innerHTML = themeToggleHTML;
            
            if (signInBtn) {
                navRight.insertBefore(wrapper.firstElementChild, signInBtn);
            } else {
                navRight.appendChild(wrapper.firstElementChild);
            }
        }
    }
    
    // Global toggle function
    window.toggleTheme = function() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        // Apply new theme
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        
        // Show notification
        showThemeNotification(newTheme);
    };
    
    function showThemeNotification(theme) {
        // Remove existing notification if any
        const existingNotif = document.querySelector('.theme-notification');
        if (existingNotif) {
            existingNotif.remove();
        }
        
        const notification = document.createElement('div');
        notification.className = 'theme-notification';
        notification.style.cssText = `
            position: fixed;
            top: 80px;
            right: 30px;
            background: ${theme === 'dark' ? '#1e293b' : '#fff'};
            color: ${theme === 'dark' ? '#f1f5f9' : '#333'};
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            z-index: 10000;
            font-weight: 600;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.3s ease;
            border: 2px solid ${theme === 'dark' ? '#38bdf8' : '#6B9BD1'};
        `;
        
        notification.innerHTML = `
            <span style="font-size: 18px;">${theme === 'dark' ? '🌙' : '☀️'}</span>
            <span>${theme === 'dark' ? 'Dark' : 'Light'} mode activated</span>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 2000);
    }
    
    // Keyboard shortcut: Ctrl+K or Cmd+K
    document.addEventListener('keydown', function(e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            toggleTheme();
        }
    });
})();