// Projects Data
let projects = [];
let currentViewingProject = null;
let currentMedia = null;

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// Load Projects
function loadProjects() {
    const storedProjects = localStorage.getItem('userProjects');
    if (storedProjects) {
        projects = JSON.parse(storedProjects);
    }
    displayProjects();
}

// Display Projects
function displayProjects() {
    const projectsGrid = document.getElementById('projectsGrid');
    const emptyState = document.getElementById('emptyState');

    if (projects.length === 0) {
        projectsGrid.style.display = 'none';
        emptyState.style.display = 'block';
    } else {
        projectsGrid.style.display = 'grid';
        emptyState.style.display = 'none';

        projectsGrid.innerHTML = projects.map((project, index) => {
            const skills = project.skills ? project.skills.slice(0, 3) : [];
            const mediaPreview = project.media ? 
                (project.mediaType === 'video' ? 
                    `<div class="project-card-media"><video src="${project.media}" muted></video></div>` :
                    `<div class="project-card-media"><img src="${project.media}" alt="Project"></div>`) 
                : '';
            
            return `
                <div class="post-card project-card" onclick="viewProject(${index})">
                    ${mediaPreview}
                    <div class="project-card-content">
                        <h3>${project.title}</h3>
                        <p class="description">${project.description.substring(0, 120)}${project.description.length > 120 ? '...' : ''}</p>
                        <div class="project-skills-preview">
                            ${skills.map(skill => `<span class="skill-chip">${skill}</span>`).join('')}
                            ${project.skills.length > 3 ? `<span class="skill-chip">+${project.skills.length - 3} more</span>` : ''}
                        </div>
                        <div class="post-footer">
                            <span class="post-author">By ${project.author}</span>
                            <span class="post-date">${project.date}</span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }
}

// Open Add Project Modal
function openAddProjectModal() {
    document.getElementById('addProjectModal').classList.add('active');
    currentMedia = null;
}

// Close Add Project Modal
function closeAddProjectModal() {
    document.getElementById('addProjectModal').classList.remove('active');
    document.getElementById('addProjectForm').reset();
    document.getElementById('mediaPreview').style.display = 'none';
    document.querySelector('.upload-placeholder').style.display = 'flex';
    currentMedia = null;
}

// Handle Media Upload
function handleMediaUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        currentMedia = {
            data: e.target.result,
            type: file.type.startsWith('video') ? 'video' : 'image',
            name: file.name
        };

        // Show preview
        const preview = document.getElementById('mediaPreview');
        const placeholder = document.querySelector('.upload-placeholder');
        
        if (currentMedia.type === 'video') {
            preview.innerHTML = `
                <video controls>
                    <source src="${currentMedia.data}" type="${file.type}">
                </video>
                <button type="button" class="remove-media-btn" onclick="removeMedia()">Remove</button>
            `;
        } else {
            preview.innerHTML = `
                <img src="${currentMedia.data}" alt="Preview">
                <button type="button" class="remove-media-btn" onclick="removeMedia()">Remove</button>
            `;
        }
        
        placeholder.style.display = 'none';
        preview.style.display = 'block';
    };
    reader.readAsDataURL(file);
}

// Remove Media
function removeMedia() {
    currentMedia = null;
    document.getElementById('mediaPreview').style.display = 'none';
    document.querySelector('.upload-placeholder').style.display = 'flex';
    document.getElementById('projectMedia').value = '';
}

// Create Project
function createProject(event) {
    event.preventDefault();

    const user = JSON.parse(localStorage.getItem('user'));
    const userName = user ? user.fullName : 'Anonymous';

    const title = document.getElementById('projectTitle').value.trim();
    const description = document.getElementById('projectDescription').value.trim();
    const skillsInput = document.getElementById('projectSkills').value.trim();
    const objectives = document.getElementById('projectObjectives').value.trim();
    const useCase = document.getElementById('projectUseCase').value.trim();
    const remarks = document.getElementById('projectRemarks').value.trim();
    const github = document.getElementById('projectGithub').value.trim();
    const demo = document.getElementById('projectDemo').value.trim();

    // Parse skills
    const skills = skillsInput.split(',').map(s => s.trim()).filter(s => s);

    const newProject = {
        id: Date.now(),
        title: title,
        description: description,
        skills: skills,
        objectives: objectives || null,
        useCase: useCase || null,
        remarks: remarks || null,
        github: github || null,
        demo: demo || null,
        media: currentMedia ? currentMedia.data : null,
        mediaType: currentMedia ? currentMedia.type : null,
        author: userName,
        date: new Date().toLocaleDateString(),
        timestamp: new Date().toISOString()
    };

    projects.unshift(newProject); // Add to beginning
    saveProjects();
    displayProjects();
    closeAddProjectModal();
    
    // Record project creation with date for timeline graph
    recordProjectCreation();
    
    showNotification('Project created successfully! 🎉');
}

// Record Project Creation (for timeline tracking)
function recordProjectCreation() {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    
    // Get existing history
    let applicationHistory = JSON.parse(localStorage.getItem('applicationHistory')) || [];
    
    // Find or create today's entry
    let todayEntry = applicationHistory.find(entry => entry.date === today);
    
    if (!todayEntry) {
        todayEntry = {
            date: today,
            jobs: 0,
            internships: 0,
            posts: 0
        };
        applicationHistory.push(todayEntry);
    }
    
    // Increment posts counter (projects count as posts)
    todayEntry.posts++;
    
    // Sort by date
    applicationHistory.sort((a, b) => new Date(a.date) - new Date(b.date));
    
    // Keep only last 30 days
    if (applicationHistory.length > 30) {
        applicationHistory = applicationHistory.slice(-30);
    }
    
    // Save to localStorage
    localStorage.setItem('applicationHistory', JSON.stringify(applicationHistory));
}

// Save Projects
function saveProjects() {
    localStorage.setItem('userProjects', JSON.stringify(projects));
    // Also update userPosts for backward compatibility with dashboard
    localStorage.setItem('userPosts', JSON.stringify(projects));
}

// View Project
function viewProject(index) {
    currentViewingProject = projects[index];

    document.getElementById('viewProjectTitle').textContent = currentViewingProject.title;

    // Display media
    const mediaDisplay = document.getElementById('viewProjectMedia');
    if (currentViewingProject.media) {
        if (currentViewingProject.mediaType === 'video') {
            mediaDisplay.innerHTML = `
                <video controls>
                    <source src="${currentViewingProject.media}">
                </video>
            `;
        } else {
            mediaDisplay.innerHTML = `<img src="${currentViewingProject.media}" alt="Project Image">`;
        }
        mediaDisplay.style.display = 'block';
    } else {
        mediaDisplay.style.display = 'none';
    }

    document.getElementById('viewProjectDescription').textContent = currentViewingProject.description;

    // Display skills
    const skillsDisplay = document.getElementById('viewProjectSkills');
    skillsDisplay.innerHTML = currentViewingProject.skills.map(skill => 
        `<span class="skill-badge">${skill}</span>`
    ).join('');

    // Objectives
    if (currentViewingProject.objectives) {
        document.getElementById('viewProjectObjectives').textContent = currentViewingProject.objectives;
        document.getElementById('viewObjectivesSection').style.display = 'block';
    } else {
        document.getElementById('viewObjectivesSection').style.display = 'none';
    }

    // Use Case
    if (currentViewingProject.useCase) {
        document.getElementById('viewProjectUseCase').textContent = currentViewingProject.useCase;
        document.getElementById('viewUseCaseSection').style.display = 'block';
    } else {
        document.getElementById('viewUseCaseSection').style.display = 'none';
    }

    // Remarks
    if (currentViewingProject.remarks) {
        document.getElementById('viewProjectRemarks').textContent = currentViewingProject.remarks;
        document.getElementById('viewRemarksSection').style.display = 'block';
    } else {
        document.getElementById('viewRemarksSection').style.display = 'none';
    }

    // Links
    const linksDisplay = document.getElementById('viewProjectLinks');
    let hasLinks = false;
    let linksHTML = '';

    if (currentViewingProject.github) {
        linksHTML += `<a href="${currentViewingProject.github}" target="_blank" class="project-link">
            <span>🔗</span> GitHub Repository
        </a>`;
        hasLinks = true;
    }

    if (currentViewingProject.demo) {
        linksHTML += `<a href="${currentViewingProject.demo}" target="_blank" class="project-link">
            <span>🚀</span> Live Demo
        </a>`;
        hasLinks = true;
    }

    if (hasLinks) {
        linksDisplay.innerHTML = linksHTML;
        document.getElementById('viewLinksSection').style.display = 'block';
    } else {
        document.getElementById('viewLinksSection').style.display = 'none';
    }

    document.getElementById('viewProjectAuthor').textContent = currentViewingProject.author;
    document.getElementById('viewProjectDate').textContent = currentViewingProject.date;

    document.getElementById('viewProjectModal').classList.add('active');
}

// Close View Project Modal
function closeViewProjectModal() {
    document.getElementById('viewProjectModal').classList.remove('active');
    currentViewingProject = null;
}

// Delete Current Project
function deleteCurrentProject() {
    if (currentViewingProject && confirm('Are you sure you want to delete this project?')) {
        const index = projects.findIndex(p => p.id === currentViewingProject.id);
        if (index > -1) {
            projects.splice(index, 1);
            saveProjects();
            displayProjects();
            closeViewProjectModal();
            showNotification('Project deleted successfully!');
        }
    }
}

// Show Notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 30px;
        background: #4CAF50;
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        z-index: 3000;
        animation: slideIn 0.3s ease;
        font-weight: 600;
        max-width: 350px;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Logout User
function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    }
}

// Close modals when clicking outside
document.addEventListener('click', function(e) {
    const addModal = document.getElementById('addProjectModal');
    const viewModal = document.getElementById('viewProjectModal');
    
    if (e.target === addModal) {
        closeAddProjectModal();
    }
    if (e.target === viewModal) {
        closeViewProjectModal();
    }
});

// Close modals and sidebar with Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeAddProjectModal();
        closeViewProjectModal();
        const sidebar = document.getElementById('sidebar');
        if (sidebar.classList.contains('active')) {
            toggleSidebar();
        }
    }
});

// Close sidebar when clicking on a link
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.sidebar-link').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                toggleSidebar();
            }
        });
    });
});

// Check if user is logged in
window.addEventListener('load', function() {
    const token = localStorage.getItem('token');
    if (!token) {
        alert('Please login to view your projects');
        window.location.href = 'index.html';
    } else {
        loadProjects();
    }
});

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100px);
        }
    }
`;
document.head.appendChild(style);