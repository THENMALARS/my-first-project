// Resume Data Structure
let resumeData = {
    personal: {
        fullName: '',
        email: '',
        phone: '',
        location: '',
        linkedin: '',
        website: ''
    },
    summary: '',
    education: [],
    experience: [],
    skills: [],
    certifications: []
};

// Toggle Sidebar
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// Initialize Resume
function initResume() {
    loadResumeData();
    setupSkillsInput();
}

// Load Resume Data from localStorage
function loadResumeData() {
    const saved = localStorage.getItem('resumeData');
    if (saved) {
        resumeData = JSON.parse(saved);
        populateForm();
    }
}

// Populate Form with Saved Data
function populateForm() {
    // Personal Information
    document.getElementById('fullName').value = resumeData.personal.fullName || '';
    document.getElementById('email').value = resumeData.personal.email || '';
    document.getElementById('phone').value = resumeData.personal.phone || '';
    document.getElementById('location').value = resumeData.personal.location || '';
    document.getElementById('linkedin').value = resumeData.personal.linkedin || '';
    document.getElementById('website').value = resumeData.personal.website || '';
    
    // Summary
    document.getElementById('summary').value = resumeData.summary || '';
    
    // Education
    resumeData.education.forEach(() => addEducation());
    resumeData.education.forEach((edu, index) => {
        const item = document.querySelectorAll('#educationList .dynamic-item')[index];
        item.querySelector('.edu-degree').value = edu.degree;
        item.querySelector('.edu-school').value = edu.school;
        item.querySelector('.edu-year').value = edu.year;
    });
    
    // Experience
    resumeData.experience.forEach(() => addExperience());
    resumeData.experience.forEach((exp, index) => {
        const item = document.querySelectorAll('#experienceList .dynamic-item')[index];
        item.querySelector('.exp-title').value = exp.title;
        item.querySelector('.exp-company').value = exp.company;
        item.querySelector('.exp-duration').value = exp.duration;
        item.querySelector('.exp-description').value = exp.description;
    });
    
    // Skills
    displaySkills();
    
    // Certifications
    resumeData.certifications.forEach(() => addCertification());
    resumeData.certifications.forEach((cert, index) => {
        const item = document.querySelectorAll('#certificationsList .dynamic-item')[index];
        item.querySelector('.cert-name').value = cert.name;
        item.querySelector('.cert-issuer').value = cert.issuer;
        item.querySelector('.cert-year').value = cert.year;
    });
}

// Setup Skills Input
function setupSkillsInput() {
    const skillInput = document.getElementById('skillInput');
    skillInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            const skill = this.value.trim();
            if (skill && !resumeData.skills.includes(skill)) {
                resumeData.skills.push(skill);
                displaySkills();
                this.value = '';
            }
        }
    });
}

// Display Skills
function displaySkills() {
    const skillsList = document.getElementById('skillsList');
    skillsList.innerHTML = resumeData.skills.map((skill, index) => `
        <div class="skill-tag">
            ${skill}
            <button onclick="removeSkill(${index})">×</button>
        </div>
    `).join('');
}

// Remove Skill
function removeSkill(index) {
    resumeData.skills.splice(index, 1);
    displaySkills();
}

// Add Education
function addEducation() {
    const list = document.getElementById('educationList');
    const index = list.children.length;
    
    const item = document.createElement('div');
    item.className = 'dynamic-item';
    item.innerHTML = `
        <button class="remove-btn" onclick="removeEducation(this)">×</button>
        <div class="form-row">
            <div class="form-group">
                <label>Degree/Qualification</label>
                <input type="text" class="edu-degree" placeholder="Bachelor of Science">
            </div>
            <div class="form-group">
                <label>School/University</label>
                <input type="text" class="edu-school" placeholder="Harvard University">
            </div>
        </div>
        <div class="form-group">
            <label>Year/Duration</label>
            <input type="text" class="edu-year" placeholder="2018 - 2022">
        </div>
    `;
    list.appendChild(item);
}

// Remove Education
function removeEducation(btn) {
    btn.parentElement.remove();
}

// Add Experience
function addExperience() {
    const list = document.getElementById('experienceList');
    
    const item = document.createElement('div');
    item.className = 'dynamic-item';
    item.innerHTML = `
        <button class="remove-btn" onclick="removeExperience(this)">×</button>
        <div class="form-row">
            <div class="form-group">
                <label>Job Title</label>
                <input type="text" class="exp-title" placeholder="Software Engineer">
            </div>
            <div class="form-group">
                <label>Company</label>
                <input type="text" class="exp-company" placeholder="Tech Corp">
            </div>
        </div>
        <div class="form-group">
            <label>Duration</label>
            <input type="text" class="exp-duration" placeholder="Jan 2020 - Present">
        </div>
        <div class="form-group">
            <label>Description</label>
            <textarea class="exp-description" rows="3" placeholder="Describe your responsibilities and achievements..."></textarea>
        </div>
    `;
    list.appendChild(item);
}

// Remove Experience
function removeExperience(btn) {
    btn.parentElement.remove();
}

// Add Certification
function addCertification() {
    const list = document.getElementById('certificationsList');
    
    const item = document.createElement('div');
    item.className = 'dynamic-item';
    item.innerHTML = `
        <button class="remove-btn" onclick="removeCertification(this)">×</button>
        <div class="form-row">
            <div class="form-group">
                <label>Certification Name</label>
                <input type="text" class="cert-name" placeholder="AWS Certified Solutions Architect">
            </div>
            <div class="form-group">
                <label>Issuing Organization</label>
                <input type="text" class="cert-issuer" placeholder="Amazon Web Services">
            </div>
        </div>
        <div class="form-group">
            <label>Year</label>
            <input type="text" class="cert-year" placeholder="2023">
        </div>
    `;
    list.appendChild(item);
}

// Remove Certification
function removeCertification(btn) {
    btn.parentElement.remove();
}

// Collect Form Data
function collectFormData() {
    // Personal Info
    resumeData.personal = {
        fullName: document.getElementById('fullName').value.trim(),
        email: document.getElementById('email').value.trim(),
        phone: document.getElementById('phone').value.trim(),
        location: document.getElementById('location').value.trim(),
        linkedin: document.getElementById('linkedin').value.trim(),
        website: document.getElementById('website').value.trim()
    };
    
    // Summary
    resumeData.summary = document.getElementById('summary').value.trim();
    
    // Education
    resumeData.education = [];
    document.querySelectorAll('#educationList .dynamic-item').forEach(item => {
        resumeData.education.push({
            degree: item.querySelector('.edu-degree').value.trim(),
            school: item.querySelector('.edu-school').value.trim(),
            year: item.querySelector('.edu-year').value.trim()
        });
    });
    
    // Experience
    resumeData.experience = [];
    document.querySelectorAll('#experienceList .dynamic-item').forEach(item => {
        resumeData.experience.push({
            title: item.querySelector('.exp-title').value.trim(),
            company: item.querySelector('.exp-company').value.trim(),
            duration: item.querySelector('.exp-duration').value.trim(),
            description: item.querySelector('.exp-description').value.trim()
        });
    });
    
    // Certifications
    resumeData.certifications = [];
    document.querySelectorAll('#certificationsList .dynamic-item').forEach(item => {
        resumeData.certifications.push({
            name: item.querySelector('.cert-name').value.trim(),
            issuer: item.querySelector('.cert-issuer').value.trim(),
            year: item.querySelector('.cert-year').value.trim()
        });
    });
}

// Save Resume
function saveResume() {
    collectFormData();
    
    if (!resumeData.personal.fullName || !resumeData.personal.email) {
        showNotification('Please fill in your name and email!', 'error');
        return;
    }
    
    localStorage.setItem('resumeData', JSON.stringify(resumeData));
    showNotification('Resume saved successfully! ✓');
}

// Preview Resume
function previewResume() {
    collectFormData();
    
    if (!resumeData.personal.fullName) {
        showNotification('Please add your name first!', 'error');
        return;
    }
    
    const preview = document.getElementById('resumePreview');
    preview.innerHTML = generateResumeHTML();
    document.getElementById('previewModal').classList.add('active');
}

// Close Preview
function closePreview() {
    document.getElementById('previewModal').classList.remove('active');
}

// Generate Resume HTML
function generateResumeHTML() {
    let html = `
        <h3>${resumeData.personal.fullName}</h3>
        <div class="contact-info">
            ${resumeData.personal.email ? `${resumeData.personal.email}` : ''}
            ${resumeData.personal.phone ? ` | ${resumeData.personal.phone}` : ''}
            ${resumeData.personal.location ? ` | ${resumeData.personal.location}` : ''}<br>
            ${resumeData.personal.linkedin ? `LinkedIn: ${resumeData.personal.linkedin}<br>` : ''}
            ${resumeData.personal.website ? `Portfolio: ${resumeData.personal.website}` : ''}
        </div>
    `;
    
    if (resumeData.summary) {
        html += `
            <div class="section-title">Professional Summary</div>
            <p>${resumeData.summary}</p>
        `;
    }
    
    if (resumeData.experience.length > 0) {
        html += '<div class="section-title">Work Experience</div>';
        resumeData.experience.forEach(exp => {
            if (exp.title) {
                html += `
                    <div class="item">
                        <div class="item-header">
                            <div>
                                <div class="item-title">${exp.title}</div>
                                <div class="item-subtitle">${exp.company}</div>
                            </div>
                            <div class="item-date">${exp.duration}</div>
                        </div>
                        ${exp.description ? `<div class="item-description">${exp.description}</div>` : ''}
                    </div>
                `;
            }
        });
    }
    
    if (resumeData.education.length > 0) {
        html += '<div class="section-title">Education</div>';
        resumeData.education.forEach(edu => {
            if (edu.degree) {
                html += `
                    <div class="item">
                        <div class="item-header">
                            <div>
                                <div class="item-title">${edu.degree}</div>
                                <div class="item-subtitle">${edu.school}</div>
                            </div>
                            <div class="item-date">${edu.year}</div>
                        </div>
                    </div>
                `;
            }
        });
    }
    
    if (resumeData.skills.length > 0) {
        html += '<div class="section-title">Skills</div>';
        html += '<div class="skills-grid">';
        resumeData.skills.forEach(skill => {
            html += `<div class="skill-item">• ${skill}</div>`;
        });
        html += '</div>';
    }
    
    if (resumeData.certifications.length > 0) {
        html += '<div class="section-title">Certifications</div>';
        resumeData.certifications.forEach(cert => {
            if (cert.name) {
                html += `
                    <div class="item">
                        <div class="item-header">
                            <div>
                                <div class="item-title">${cert.name}</div>
                                <div class="item-subtitle">${cert.issuer}</div>
                            </div>
                            <div class="item-date">${cert.year}</div>
                        </div>
                    </div>
                `;
            }
        });
    }
    
    return html;
}

// Download Resume
function downloadResume() {
    collectFormData();
    
    if (!resumeData.personal.fullName) {
        showNotification('Please add your name first!', 'error');
        return;
    }
    
    // Generate HTML for download
    const resumeHTML = generateResumeHTML();
    
    // Create a complete HTML document
    const fullHTML = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${resumeData.personal.fullName} - Resume</title>
    <style>
        body {
            font-family: Georgia, serif;
            max-width: 800px;
            margin: 40px auto;
            padding: 40px;
            line-height: 1.6;
            color: #333;
        }
        h3 {
            color: #1a3a52;
            font-size: 28px;
            margin-bottom: 10px;
            text-align: center;
        }
        .contact-info {
            text-align: center;
            color: #555;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #ddd;
        }
        .section-title {
            color: #1a3a52;
            font-size: 18px;
            font-weight: 700;
            margin-top: 20px;
            margin-bottom: 12px;
            border-bottom: 2px solid #6B9BD1;
            padding-bottom: 5px;
        }
        .item {
            margin-bottom: 15px;
        }
        .item-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        .item-title {
            font-weight: 700;
            color: #333;
        }
        .item-subtitle {
            color: #666;
            font-style: italic;
        }
        .item-date {
            color: #888;
            font-size: 14px;
        }
        .item-description {
            color: #555;
            line-height: 1.6;
        }
        .skills-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
        }
        .skill-item {
            color: #555;
        }
        @media print {
            body {
                margin: 0;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    ${resumeHTML}
</body>
</html>
    `;
    
    // Create blob and download
    const blob = new Blob([fullHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${resumeData.personal.fullName.replace(/\s+/g, '_')}_Resume.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showNotification('Resume downloaded! You can print it to PDF from your browser. ✓');
}

// Clear Resume
function clearResume() {
    if (confirm('Are you sure you want to clear all resume data? This cannot be undone.')) {
        localStorage.removeItem('resumeData');
        window.location.reload();
    }
}

// Show Notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    const bgColor = type === 'error' ? '#f44336' : '#4CAF50';
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 30px;
        background: ${bgColor};
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        z-index: 3000;
        animation: slideIn 0.3s ease;
        font-weight: 600;
        max-width: 350px;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Logout User
function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    }
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    const modal = document.getElementById('previewModal');
    if (e.target === modal) {
        closePreview();
    }
});

// Close modal and sidebar with Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePreview();
        const sidebar = document.getElementById('sidebar');
        if (sidebar.classList.contains('active')) {
            toggleSidebar();
        }
    }
});

// Close sidebar when clicking on a link
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.sidebar-link').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                toggleSidebar();
            }
        });
    });
});

// Check if user is logged in
window.addEventListener('load', function() {
    const token = localStorage.getItem('token');
    
    if (!token) {
        alert('Please login to update your resume');
        window.location.href = 'index.html';
    } else {
        initResume();
    }
});

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100px);
        }
    }
`;
document.head.appendChild(style);