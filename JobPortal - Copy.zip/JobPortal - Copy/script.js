// API Base URL - Update this to your backend URL
const API_URL = 'http://localhost:5000/api/auth';

// Show/Hide Forms
function showForm(formName) {
    const forms = ['loginForm', 'registerForm', 'forgotForm', 'dashboard'];
    forms.forEach(form => {
        document.getElementById(form).classList.add('hidden');
    });

    if (formName === 'login') {
        document.getElementById('loginForm').classList.remove('hidden');
    } else if (formName === 'register') {
        document.getElementById('registerForm').classList.remove('hidden');
    } else if (formName === 'forgot') {
        document.getElementById('forgotForm').classList.remove('hidden');
    }

    hideAlert();
}

// Toggle Password Visibility
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const toggle = input.nextElementSibling;

    if (input.type === 'password') {
        input.type = 'text';
        toggle.textContent = 'Hide';
    } else {
        input.type = 'password';
        toggle.textContent = 'Show';
    }
}

// Role Selection
document.querySelectorAll('.role-option').forEach(option => {
    option.addEventListener('click', function() {
        document.querySelectorAll('.role-option').forEach(opt => {
            opt.classList.remove('selected');
        });
        this.classList.add('selected');
        this.querySelector('input[type="radio"]').checked = true;
    });
});

// Alert Functions
function showAlert(message, type) {
    const alert = document.getElementById('alert');
    alert.className = `alert alert-${type}`;
    alert.textContent = message;
    alert.classList.remove('hidden');

    setTimeout(() => {
        hideAlert();
    }, 5000);
}

function hideAlert() {
    document.getElementById('alert').classList.add('hidden');
}

// Helper function to get user-specific key
function getUserKey(baseKey) {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const userId = user.id || user.email || 'default';
    return `${baseKey}_${userId}`;
}

// Clear all previous user data when logging in as different user
function clearPreviousUserData() {
    const keysToKeep = ['token', 'user'];
    const allKeys = Object.keys(localStorage);
    
    allKeys.forEach(key => {
        if (!keysToKeep.includes(key)) {
            localStorage.removeItem(key);
        }
    });
}

// Login Form Submit
document.getElementById('login').addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch(`${API_URL}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (response.ok) {
            // Clear previous user data first
            clearPreviousUserData();
            
            // Save token and user data
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));

            showAlert('Login successful!', 'success');

            // Redirect based on role after a brief delay
            setTimeout(() => {
                redirectToDashboard(data.user);
            }, 1000);
        } else {
            showAlert(data.message || 'Login failed', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showAlert('Network error. Please try again.', 'error');
    }
});

// Register Form Submit
document.getElementById('register').addEventListener('submit', async (e) => {
    e.preventDefault();

    const fullName = document.getElementById('fullName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const role = document.querySelector('input[name="role"]:checked')?.value;
    const securityQuestion = document.getElementById('securityQuestion').value;
    const securityAnswer = document.getElementById('securityAnswer').value;

    if (!role) {
        showAlert('Please select a role', 'error');
        return;
    }

    if (password !== confirmPassword) {
        showAlert('Passwords do not match', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                fullName,
                email,
                password,
                confirmPassword,
                role,
                securityQuestion,
                securityAnswer
            })
        });

        const data = await response.json();

        if (response.ok) {
            showAlert('Registration successful! Please login.', 'success');

            // Clear form
            document.getElementById('register').reset();
            document.querySelectorAll('.role-option').forEach(opt => {
                opt.classList.remove('selected');
            });

            // Redirect to login
            setTimeout(() => {
                showForm('login');
            }, 2000);
        } else {
            showAlert(data.message || 'Registration failed', 'error');
        }
    } catch (error) {
        console.error('Registration error:', error);
        showAlert('Network error. Please try again.', 'error');
    }
});

// Forgot Password Form Submit
document.getElementById('forgot').addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = document.getElementById('forgotEmail').value;
    const securityAnswer = document.getElementById('forgotSecurityAnswer').value;
    const newPassword = document.getElementById('newPassword').value;

    try {
        const response = await fetch(`${API_URL}/forgot-password`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email,
                securityAnswer,
                newPassword
            })
        });

        const data = await response.json();

        if (response.ok) {
            showAlert('Password reset successful! Please login.', 'success');

            // Clear form
            document.getElementById('forgot').reset();

            // Redirect to login
            setTimeout(() => {
                showForm('login');
            }, 2000);
        } else {
            showAlert(data.message || 'Password reset failed', 'error');
        }
    } catch (error) {
        console.error('Password reset error:', error);
        showAlert('Network error. Please try again.', 'error');
    }
});

// Redirect to Dashboard based on Role
function redirectToDashboard(user) {
    console.log('Redirecting user:', user); // Debug log
    console.log('User role:', user.role); // Debug log
    
    // If in iframe (popup), send message to parent
    if (window.parent !== window) {
        window.parent.postMessage({
            type: 'loginSuccess',
            user: user
        }, '*');
    } else {
        // Direct redirection based on role - CORRECTED LOGIC
        if (user.role === 'employee') {
            console.log('Redirecting to employer dashboard'); // Debug log
            window.location.href = 'employer-dashboard.html';
        } else if (user.role === 'jobseeker') {
            console.log('Redirecting to job seeker dashboard'); // Debug log
            window.location.href = 'dashboard.html';
        } else {
            console.error('Unknown role:', user.role);
            showAlert('Unknown user role. Please contact support.', 'error');
        }
    }
}

// Send message to parent window after successful login
function showDashboard(user) {
    redirectToDashboard(user);
}

// Logout
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    showAlert('Logged out successfully', 'success');

    setTimeout(() => {
        showForm('login');
        // Clear login form
        document.getElementById('login').reset();
    }, 1000);
}

function notifyParentOfLogin(user) {
    if (window.parent !== window) {
        // We're in an iframe, send message to parent
        window.parent.postMessage({
            type: 'loginSuccess',
            user: user
        }, '*');
    }
}

// Check if user is already logged in
window.addEventListener('load', () => {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');

    if (token && user) {
        const userData = JSON.parse(user);
        console.log('Auto-redirecting logged in user:', userData); // Debug log
        redirectToDashboard(userData);
    }
});